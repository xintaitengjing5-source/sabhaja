import { useMemo, useState, type ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Sparkles, UtensilsCrossed } from "lucide-react";
import { toast } from "sonner";
import { AppHeader } from "@/components/app-header";
import { GoalsDialog } from "@/components/goals-dialog";
import { HeroBlock } from "@/components/hero-block";
import { HinataMark } from "@/components/mark";
import { Macros } from "@/components/macros";
import { Pantry } from "@/components/pantry";
import { RecipeCard } from "@/components/recipe-card";
import { WeekStrip } from "@/components/week-strip";
import { WeeklyBars } from "@/components/weekly-bars";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { todayKey } from "@/lib/date";
import { suggestMeals } from "@/lib/suggest";
import { useKitchen } from "@/lib/store";
import { cn } from "@/lib/cn";
import {
  PACE_LABEL,
  VIBE_BLURB,
  VIBE_LABEL,
  type Pace,
  type SuggestedMeal,
  type Vibe,
} from "@/lib/types";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const today = todayKey();
  const [goalsOpen, setGoalsOpen] = useState(false);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <AppHeader onOpenGoals={() => setGoalsOpen(true)} />
      <KitchenApp today={today} goalsOpen={goalsOpen} setGoalsOpen={setGoalsOpen} />
    </div>
  );
}

function KitchenApp({
  today,
  goalsOpen,
  setGoalsOpen,
}: {
  today: string;
  goalsOpen: boolean;
  setGoalsOpen: (open: boolean) => void;
}) {
  const ingredients = useKitchen((s) => s.ingredients);
  const profile = useKitchen((s) => s.profile);
  const pace = useKitchen((s) => s.pace);
  const setPace = useKitchen((s) => s.setPace);
  const mealCount = useKitchen((s) => s.mealCount);
  const setMealCount = useKitchen((s) => s.setMealCount);
  const isCheat = useKitchen((s) => s.isCheat(today));
  const lastPlan = useKitchen((s) => s.lastPlan);
  const setPlan = useKitchen((s) => s.setPlan);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const plan = lastPlan?.date === today ? lastPlan : null;
  const showingCheat = plan ? plan.cheat : isCheat;

  async function generate() {
    if (ingredients.length === 0) {
      toast("先に食材を入れてください");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const result = await suggestMeals({
        data: {
          ingredients: ingredients.map((item) => item.name),
          avoids: profile.avoids,
          goal: profile.goal,
          calories: profile.calories,
          protein: profile.protein,
          servings: profile.servings,
          cheat: isCheat,
          mealCount,
          pace,
          recentTitles: plan?.meals.map((m) => m.title) ?? [],
        },
      });
      setPlan({
        date: today,
        cheat: isCheat,
        advice: result.advice,
        meals: result.meals,
      });
    } catch {
      setError("通信に失敗しました。もう一度どうぞ。");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <main className="mx-auto grid max-w-6xl gap-8 px-4 py-8 pb-36 lg:grid-cols-[minmax(0,22rem)_1fr] lg:items-start lg:pb-12">
        <div className="lg:col-start-1">
          <HeroBlock today={today} cheat={showingCheat} />
        </div>

        <div className="space-y-5 lg:col-start-2 lg:row-start-1 lg:row-span-2">
          <Pantry />

          <section className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-xs tracking-widest text-muted">候補の出し方</p>
              <span className="text-xs text-subtle">
                {profile.servings}人分 / {profile.calories}kcal
              </span>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {([1, 3] as const).map((count) => (
                <button
                  key={count}
                  type="button"
                  onClick={() => setMealCount(count)}
                  className={cn(
                    "h-11 rounded-full px-4 text-sm transition-colors duration-150",
                    mealCount === count
                      ? "bg-primary text-primary-fg"
                      : "bg-elevated text-muted hover:text-fg",
                  )}
                >
                  {count === 1 ? "候補を少し" : "候補を多め"}
                </button>
              ))}
              {(Object.keys(PACE_LABEL) as Pace[]).map((key) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setPace(key)}
                  className={cn(
                    "h-11 rounded-full px-4 text-sm transition-colors duration-150",
                    pace === key
                      ? "bg-primary text-primary-fg"
                      : "bg-elevated text-muted hover:text-fg",
                  )}
                >
                  {PACE_LABEL[key]}
                </button>
              ))}
            </div>
            <Button
              className="mt-4 hidden w-full lg:inline-flex"
              size="lg"
              variant={isCheat ? "cheat" : "primary"}
              onClick={() => void generate()}
              disabled={loading}
            >
              {loading ? "候補を出しています" : isCheat ? "ごちそうの候補を出す" : "献立の候補を出す"}
            </Button>
          </section>

          {loading && (
            <div className="rounded-xl bg-surface p-8 text-center shadow-[var(--shadow-border)]">
              <HinataMark className="mx-auto size-10 text-primary" />
              <p className="shimmer-text mt-4 font-display text-xl">
                ひなたの台所で、候補を揃えています
              </p>
              <div className="mt-6 space-y-3">
                <Skeleton className="h-24 w-full rounded-lg" />
                <Skeleton className="h-24 w-full rounded-lg" />
              </div>
            </div>
          )}

          {error && !loading && (
            <div className="rounded-xl bg-cheat-soft px-4 py-4 text-sm text-cheat">
              {error}
            </div>
          )}

          {!loading && plan && (
            <MenuBoard meals={plan.meals} advice={plan.advice} today={today} cheat={plan.cheat} />
          )}

          {!loading && !plan && !error && (
            <EmptyPlan cheat={isCheat} onGenerate={() => void generate()} />
          )}
        </div>

        <aside className="space-y-5 lg:col-start-1 lg:sticky lg:top-24">
          <WeekStrip today={today} />
          <Macros today={today} cheat={showingCheat} />
          <WeeklyBars today={today} />
        </aside>
      </main>

      <div className="fixed inset-x-0 bottom-14 z-40 border-t border-border bg-bg/92 p-3 backdrop-blur-sm lg:hidden">
        <Button
          className="w-full"
          size="lg"
          variant={isCheat ? "cheat" : "primary"}
          onClick={() => void generate()}
          disabled={loading}
        >
          {loading ? "候補を出しています" : isCheat ? "ごちそうの候補を出す" : "献立の候補を出す"}
        </Button>
      </div>

      <GoalsDialog open={goalsOpen} onOpenChange={setGoalsOpen} today={today} />
    </>
  );
}

function MenuBoard({
  meals,
  advice,
  today,
  cheat,
}: {
  meals: SuggestedMeal[];
  advice: string;
  today: string;
  cheat: boolean;
}) {
  const [filter, setFilter] = useState<Vibe | "all">("all");
  const order: Vibe[] = cheat ? ["feast", "home", "light"] : ["home", "feast", "light"];

  const grouped = useMemo(() => {
    const map: Record<Vibe, SuggestedMeal[]> = { light: [], home: [], feast: [] };
    for (const meal of meals) {
      map[meal.vibe ?? "home"].push(meal);
    }
    return map;
  }, [meals]);

  const visible = filter === "all" ? order : [filter];

  return (
    <div className="space-y-6">
      <p className="font-display text-lg leading-snug text-muted">{advice}</p>
      <div className="flex flex-wrap gap-2">
        <FilterChip
          active={filter === "all"}
          onClick={() => setFilter("all")}
        >
          全部 {meals.length}
        </FilterChip>
        {order.map((vibe) => (
          <FilterChip
            key={vibe}
            active={filter === vibe}
            onClick={() => setFilter(vibe)}
            accent={vibe === "feast"}
          >
            {VIBE_LABEL[vibe]} {grouped[vibe].length}
          </FilterChip>
        ))}
      </div>
      {visible.map((vibe) => {
        const list = grouped[vibe];
        if (list.length === 0) return null;
        return (
          <section key={vibe} className="space-y-3">
            <div>
              <h2 className="font-display text-2xl">{VIBE_LABEL[vibe]}</h2>
              <p className="mt-1 text-sm text-muted">{VIBE_BLURB[vibe]}</p>
            </div>
            {list.map((meal, i) => (
              <RecipeCard
                key={`${meal.title}-${i}`}
                meal={meal}
                today={today}
                cheat={cheat}
                defaultOpen={i === 0 && (filter !== "all" || vibe === (cheat ? "feast" : "home"))}
              />
            ))}
          </section>
        );
      })}
    </div>
  );
}

function FilterChip({
  active,
  onClick,
  children,
  accent,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  accent?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-11 rounded-full px-4 text-sm transition-colors duration-150",
        active
          ? accent
            ? "bg-cheat text-primary-fg"
            : "bg-primary text-primary-fg"
          : "bg-elevated text-muted hover:text-fg",
      )}
    >
      {children}
    </button>
  );
}

function EmptyPlan({
  cheat,
  onGenerate,
}: {
  cheat: boolean;
  onGenerate: () => void;
}) {
  return (
    <div className="rounded-xl bg-surface px-5 py-12 text-center shadow-[var(--shadow-border)]">
      <div className="mx-auto flex size-14 items-center justify-center rounded-full bg-elevated text-primary">
        {cheat ? <Sparkles className="size-6" /> : <UtensilsCrossed className="size-6" />}
      </div>
      <h2 className="mt-5 font-display text-2xl">
        {cheat ? "今日は、少し贅沢に。" : "食材を入れて、候補を出す。"}
      </h2>
      <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-muted">
        {cheat
          ? "冷蔵庫のものとつながったごちそうを、いくつか出します。"
          : "生姜焼き、親子丼、カレーから、からあげまで。食べたいものを選んでください。"}
      </p>
      <Button
        variant="outline"
        className="mt-6 hidden lg:inline-flex"
        onClick={onGenerate}
      >
        候補を出す
      </Button>
    </div>
  );
}
