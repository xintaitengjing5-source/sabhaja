export type Goal = "cut" | "maintain" | "bulk";

export type MealType = "breakfast" | "lunch" | "dinner" | "snack";

export type Pace = "quick" | "normal" | "slow";

export type Vibe = "light" | "home" | "feast";

export type Ingredient = {
  id: string;
  name: string;
  category: string;
};

export type Profile = {
  goal: Goal;
  calories: number;
  protein: number;
  servings: number;
  avoids: string[];
};

export type MealLog = {
  id: string;
  date: string;
  title: string;
  mealType: MealType;
  calories: number;
  protein: number;
  fat: number;
  carbs: number;
};

export type MealPart = {
  name: string;
  amount: string;
};

export type SuggestedMeal = {
  title: string;
  mealType: MealType;
  vibe: Vibe;
  minutes: number;
  calories: number;
  protein: number;
  fat: number;
  carbs: number;
  why: string;
  used: string[];
  extras: string[];
  parts: MealPart[];
  steps: string[];
  tip: string;
};

export type DayPlan = {
  date: string;
  cheat: boolean;
  advice: string;
  meals: SuggestedMeal[];
};

export const GOAL_LABEL: Record<Goal, string> = {
  cut: "減量",
  maintain: "維持",
  bulk: "増量",
};

export const MEAL_LABEL: Record<MealType, string> = {
  breakfast: "朝",
  lunch: "昼",
  dinner: "夜",
  snack: "間",
};

export const MEAL_FULL: Record<MealType, string> = {
  breakfast: "朝食",
  lunch: "昼食",
  dinner: "夕食",
  snack: "間食",
};

export const PACE_LABEL: Record<Pace, string> = {
  quick: "時短",
  normal: "ふつう",
  slow: "じっくり",
};

export const VIBE_LABEL: Record<Vibe, string> = {
  light: "からだ向き",
  home: "いつものごはん",
  feast: "ごちそう",
};

export const VIBE_BLURB: Record<Vibe, string> = {
  light: "あっさり。野菜多め。",
  home: "普通の家庭料理。",
  feast: "味濃いめ。めちゃくちゃおいしい。",
};
