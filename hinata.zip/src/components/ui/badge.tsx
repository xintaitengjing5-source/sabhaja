import type { ComponentProps } from "react";
import { cn } from "@/lib/cn";

export function Badge({
  className,
  tone = "default",
  ...props
}: ComponentProps<"span"> & { tone?: "default" | "primary" | "cheat" }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium",
        tone === "default" && "bg-elevated text-muted",
        tone === "primary" && "bg-primary/10 text-primary",
        tone === "cheat" && "bg-cheat-soft text-cheat",
        className,
      )}
      {...props}
    />
  );
}
