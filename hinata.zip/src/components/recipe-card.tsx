import { useState } from "react";
import { Check, ChevronDown, Clock } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/cn";
import { MEAL_FULL, VIBE_LABEL, type SuggestedMeal, type Vibe } from "@/lib/types";
import { useKitchen } from "@/lib/store";
import { Button } from "./ui/button";

const VIBE_TONE: Record<Vibe, string> = {
  light: "bg-primary/10 text-primary",
  home: "bg-elevated text-muted",
  feast: "bg-cheat-soft text-cheat",
};

export function RecipeCard({
  meal,
  today,
  cheat,
  defaultOpen,
}: {
  meal: SuggestedMeal;
  today: string;
  cheat: boolean;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen ?? false);
  const logMeal = useKitchen((s) => s.logMeal);
  const logs = useKitchen((s) => s.log);
  const servings = useKitchen((s) => s.profile.servings);
  const eaten = logs.some((item) => item.date === today && item.title === meal.title);
  const vibe: Vibe = meal.vibe ?? "home";
  const parts = meal.parts ?? [];

  return (
    <article className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
      <div className="flex items-start gap-3">
        <span
          className={cn(
            "mt-0.5 shrink-0 rounded-full px-2.5 py-1 text-xs font-medium",
            VIBE_TONE[vibe],
          )}
        >
          {VIBE_LABEL[vibe]}
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-xs text-subtle">{MEAL_FULL[meal.mealType]}向き</p>
          <h3 className="mt-0.5 font-display text-xl leading-snug">{meal.title}</h3>
          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted">
            <span className="inline-flex items-center gap-1">
              <Clock className="size-3.5" />
              {meal.minutes}分
            </span>
            <span className="tabular-nums">{meal.calories} kcal</span>
            <span className="tabular-nums">P {meal.protein}g</span>
            <span className="tabular-nums">F {meal.fat}g</span>
            <span className="tabular-nums">C {meal.carbs}g</span>
          </div>
        </div>
      </div>

      <p className="mt-4 text-sm leading-relaxed text-muted">{meal.why}</p>

      {meal.used.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {meal.used.map((name) => (
            <span
              key={name}
              className="rounded-full bg-primary/10 px-2.5 py-1 text-xs text-primary"
            >
              {name}
            </span>
          ))}
          {meal.extras.map((name) => (
            <span
              key={name}
              className="rounded-full bg-elevated px-2.5 py-1 text-xs text-subtle"
            >
              足すなら {name}
            </span>
          ))}
        </div>
      )}

      <button
        type="button"
        className="mt-4 flex min-h-11 w-full items-center justify-between rounded-md py-2 text-sm text-muted hover:text-fg"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
      >
        材料と作り方
        <ChevronDown
          className={cn(
            "size-4 transition-transform duration-200",
            open && "rotate-180",
          )}
        />
      </button>
      {open && (
        <div className="space-y-4 pb-2">
          {parts.length > 0 && (
            <div>
              <p className="text-xs tracking-widest text-muted">
                材料（{servings}人分）
              </p>
              <ul className="mt-2 divide-y divide-border">
                {parts.map((part) => (
                  <li
                    key={`${part.name}-${part.amount}`}
                    className="flex items-baseline justify-between gap-4 py-1.5 text-sm"
                  >
                    <span>{part.name}</span>
                    <span className="shrink-0 tabular-nums text-muted">{part.amount}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <ol className="space-y-3">
            {meal.steps.map((step, i) => (
              <li key={i} className="flex gap-3 text-sm leading-relaxed">
                <span className="font-display text-muted tabular-nums">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
          {meal.tip ? (
            <p className="border-t border-border pt-3 text-sm text-muted">{meal.tip}</p>
          ) : null}
        </div>
      )}

      <div className="mt-2">
        <Button
          variant={eaten ? "muted" : cheat || vibe === "feast" ? "cheat" : "primary"}
          className="w-full"
          onClick={() => {
            if (eaten) return;
            logMeal(today, meal);
            toast("これにしました");
          }}
          disabled={eaten}
        >
          {eaten ? (
            <>
              <Check />
              これに決めた
            </>
          ) : (
            "これにする"
          )}
        </Button>
      </div>
    </article>
  );
}
