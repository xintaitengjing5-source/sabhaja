import { useMemo, useState } from "react";
import { Plus, X } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/cn";
import { CATALOG, CATEGORIES } from "@/lib/ingredients";
import { useKitchen } from "@/lib/store";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

export function Pantry() {
  const ingredients = useKitchen((s) => s.ingredients);
  const addIngredient = useKitchen((s) => s.addIngredient);
  const removeIngredient = useKitchen((s) => s.removeIngredient);
  const seedStarter = useKitchen((s) => s.seedStarter);
  const [query, setQuery] = useState("");
  const [openCat, setOpenCat] = useState<string | null>("野菜");

  const suggestions = useMemo(() => {
    const q = query.trim();
    if (!q) return [];
    const have = new Set(ingredients.map((item) => item.name));
    return CATALOG.filter(
      (item) => item.name.includes(q) && !have.has(item.name),
    ).slice(0, 6);
  }, [query, ingredients]);

  function submit(name: string) {
    const ok = addIngredient(name);
    if (!ok) {
      toast("すでに入っています");
      return;
    }
    setQuery("");
  }

  return (
    <section className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
      <div className="mb-4 flex items-end justify-between gap-3">
        <div>
          <p className="text-xs tracking-[0.16em] text-muted">いまある食材</p>
          <h2 className="mt-1 font-display text-xl">冷蔵庫</h2>
        </div>
        <span className="tabular-nums text-sm text-subtle">
          {ingredients.length}品
        </span>
      </div>

      <form
        className="relative"
        onSubmit={(e) => {
          e.preventDefault();
          if (query.trim()) submit(query);
        }}
      >
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="食材を入力して追加"
          aria-label="食材を追加"
          autoComplete="off"
        />
        <button
          type="submit"
          className="absolute top-1 right-1 flex size-9 items-center justify-center rounded-md text-primary transition-colors duration-150 hover:bg-elevated"
          aria-label="追加"
        >
          <Plus className="size-4" />
        </button>
        {suggestions.length > 0 && (
          <ul className="absolute z-20 mt-1 w-full overflow-hidden rounded-md bg-surface shadow-[var(--shadow-border)]">
            {suggestions.map((item) => (
              <li key={item.name}>
                <button
                  type="button"
                  className="flex w-full items-center justify-between px-3 py-2.5 text-left text-sm hover:bg-elevated"
                  onClick={() => submit(item.name)}
                >
                  <span>{item.name}</span>
                  <span className="text-xs text-subtle">{item.category}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </form>

      {ingredients.length === 0 ? (
        <div className="mt-5 rounded-lg bg-elevated/50 px-4 py-6 text-center">
          <p className="text-sm text-muted">まだ食材がありません。</p>
          <Button
            variant="outline"
            size="sm"
            className="mt-3"
            onClick={() => {
              seedStarter();
              toast("よく使う食材を入れました");
            }}
          >
            よく使う6品を入れる
          </Button>
        </div>
      ) : (
        <ul className="mt-4 flex flex-wrap gap-2">
          {ingredients.map((item) => (
            <li key={item.id}>
              <span className="inline-flex items-center gap-1 rounded-full bg-elevated py-1 pr-1 pl-3 text-sm">
                {item.name}
                <button
                  type="button"
                  className="relative flex size-7 items-center justify-center rounded-full text-muted after:absolute after:top-1/2 after:left-1/2 after:size-10 after:-translate-x-1/2 after:-translate-y-1/2 hover:text-fg"
                  onClick={() => removeIngredient(item.id)}
                  aria-label={`${item.name}を削除`}
                >
                  <X className="size-3.5" />
                </button>
              </span>
            </li>
          ))}
        </ul>
      )}

      <div className="mt-5">
        <p className="mb-2 text-xs text-subtle">カタログから選ぶ</p>
        <div className="mb-3 flex flex-wrap gap-1.5">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setOpenCat(openCat === cat ? null : cat)}
              className={cn(
                "h-8 rounded-full px-3 text-xs transition-colors duration-150",
                openCat === cat
                  ? "bg-primary text-primary-fg"
                  : "bg-elevated text-muted hover:text-fg",
              )}
            >
              {cat}
            </button>
          ))}
        </div>
        {openCat && (
          <div className="flex flex-wrap gap-1.5">
            {CATALOG.filter((item) => item.category === openCat).map((item) => {
              const have = ingredients.some((i) => i.name === item.name);
              return (
                <button
                  key={item.name}
                  type="button"
                  disabled={have}
                  onClick={() => submit(item.name)}
                  className={cn(
                    "h-8 rounded-full px-3 text-xs shadow-[var(--shadow-border)] transition-opacity duration-150",
                    have
                      ? "bg-elevated text-subtle"
                      : "bg-surface text-fg hover:bg-elevated",
                  )}
                >
                  {item.name}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
