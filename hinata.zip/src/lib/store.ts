import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type {
  DayPlan,
  Goal,
  Ingredient,
  MealLog,
  Pace,
  Profile,
  SuggestedMeal,
} from "./types";
import { categoryOf } from "./ingredients";
import { todayKey, weekdayIndex } from "./date";

const MAX_CHEAT_WEEKDAYS = 2;

type KitchenState = {
  ingredients: Ingredient[];
  profile: Profile;
  cheatWeekdays: number[];
  extraCheatDates: string[];
  log: MealLog[];
  lastPlan: DayPlan | null;
  pace: Pace;
  mealCount: 1 | 3;
  addIngredient: (name: string) => boolean;
  removeIngredient: (id: string) => void;
  seedStarter: () => void;
  clearPantry: () => void;
  setProfile: (patch: Partial<Profile>) => void;
  toggleAvoid: (name: string) => void;
  toggleCheatWeekday: (dow: number) => boolean;
  toggleTodayCheat: (dateKey: string) => void;
  isCheat: (dateKey: string) => boolean;
  setPace: (pace: Pace) => void;
  setMealCount: (count: 1 | 3) => void;
  setPlan: (plan: DayPlan) => void;
  logMeal: (dateKey: string, meal: SuggestedMeal) => void;
  removeLog: (id: string) => void;
  logsOn: (dateKey: string) => MealLog[];
};

function uid(): string {
  return Math.random().toString(36).slice(2, 10);
}

const defaultProfile: Profile = {
  goal: "maintain" satisfies Goal,
  calories: 2000,
  protein: 90,
  servings: 1,
  avoids: [],
};

export const useKitchen = create<KitchenState>()(
  persist(
    (set, get) => ({
      ingredients: [],
      profile: defaultProfile,
      cheatWeekdays: [6],
      extraCheatDates: [],
      log: [],
      lastPlan: null,
      pace: "normal",
      mealCount: 3,
      addIngredient: (raw) => {
        const name = raw.trim();
        if (!name) return false;
        const exists = get().ingredients.some((item) => item.name === name);
        if (exists) return false;
        set({
          ingredients: [
            ...get().ingredients,
            { id: uid(), name, category: categoryOf(name) },
          ],
        });
        return true;
      },
      removeIngredient: (id) =>
        set({ ingredients: get().ingredients.filter((item) => item.id !== id) }),
      seedStarter: () => {
        const names = ["卵", "玉ねぎ", "豚こま", "米", "キャベツ", "鶏もも肉"];
        const have = new Set(get().ingredients.map((item) => item.name));
        const extra = names
          .filter((name) => !have.has(name))
          .map((name) => ({ id: uid(), name, category: categoryOf(name) }));
        if (extra.length) set({ ingredients: [...get().ingredients, ...extra] });
      },
      clearPantry: () => set({ ingredients: [] }),
      setProfile: (patch) =>
        set({ profile: { ...get().profile, ...patch } }),
      toggleAvoid: (name) => {
        const avoids = get().profile.avoids;
        const next = avoids.includes(name)
          ? avoids.filter((item) => item !== name)
          : [...avoids, name];
        set({ profile: { ...get().profile, avoids: next } });
      },
      toggleCheatWeekday: (dow) => {
        const current = get().cheatWeekdays;
        if (current.includes(dow)) {
          set({ cheatWeekdays: current.filter((d) => d !== dow) });
          return true;
        }
        if (current.length >= MAX_CHEAT_WEEKDAYS) return false;
        set({ cheatWeekdays: [...current, dow] });
        return true;
      },
      toggleTodayCheat: (dateKey) => {
        const extras = get().extraCheatDates;
        if (extras.includes(dateKey)) {
          set({ extraCheatDates: extras.filter((d) => d !== dateKey) });
          return;
        }
        set({ extraCheatDates: [...extras, dateKey] });
      },
      isCheat: (dateKey) => {
        const dow = weekdayIndex(dateKey);
        const { cheatWeekdays, extraCheatDates } = get();
        const weekly = cheatWeekdays.includes(dow);
        const extra = extraCheatDates.includes(dateKey);
        return extra ? !weekly : weekly;
      },
      setPace: (pace) => set({ pace }),
      setMealCount: (mealCount) => set({ mealCount }),
      setPlan: (plan) => set({ lastPlan: plan }),
      logMeal: (dateKey, meal) =>
        set({
          log: [
            ...get().log,
            {
              id: uid(),
              date: dateKey,
              title: meal.title,
              mealType: meal.mealType,
              calories: meal.calories,
              protein: meal.protein,
              fat: meal.fat,
              carbs: meal.carbs,
            },
          ].slice(-80),
        }),
      removeLog: (id) => set({ log: get().log.filter((item) => item.id !== id) }),
      logsOn: (dateKey) => get().log.filter((item) => item.date === dateKey),
    }),
    {
      name: "hinata-kitchen-v1",
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      partialize: (state) => ({
        ingredients: state.ingredients,
        profile: state.profile,
        cheatWeekdays: state.cheatWeekdays,
        extraCheatDates: state.extraCheatDates.filter(
          (d) => d >= todayKey(),
        ),
        log: state.log.slice(-80),
        lastPlan: state.lastPlan,
        pace: state.pace,
        mealCount: state.mealCount,
      }),
    },
  ),
);
