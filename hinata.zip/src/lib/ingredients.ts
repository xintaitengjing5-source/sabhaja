export type CatalogItem = { name: string; category: string };

export const CATEGORIES = [
  "野菜",
  "肉・魚・たんぱく",
  "穀物",
  "乳・卵",
  "調味料",
  "その他",
] as const;

export const CATALOG: CatalogItem[] = [
  { name: "玉ねぎ", category: "野菜" },
  { name: "にんじん", category: "野菜" },
  { name: "じゃがいも", category: "野菜" },
  { name: "キャベツ", category: "野菜" },
  { name: "トマト", category: "野菜" },
  { name: "ほうれん草", category: "野菜" },
  { name: "ブロッコリー", category: "野菜" },
  { name: "きゅうり", category: "野菜" },
  { name: "なす", category: "野菜" },
  { name: "ピーマン", category: "野菜" },
  { name: "きのこ", category: "野菜" },
  { name: "白菜", category: "野菜" },
  { name: "ねぎ", category: "野菜" },
  { name: "小松菜", category: "野菜" },
  { name: "もやし", category: "野菜" },
  { name: "さつまいも", category: "野菜" },
  { name: "アボカド", category: "野菜" },
  { name: "レタス", category: "野菜" },
  { name: "鶏むね肉", category: "肉・魚・たんぱく" },
  { name: "鶏もも肉", category: "肉・魚・たんぱく" },
  { name: "豚こま", category: "肉・魚・たんぱく" },
  { name: "豚バラ", category: "肉・魚・たんぱく" },
  { name: "牛薄切り", category: "肉・魚・たんぱく" },
  { name: "ひき肉", category: "肉・魚・たんぱく" },
  { name: "鮭", category: "肉・魚・たんぱく" },
  { name: "さば", category: "肉・魚・たんぱく" },
  { name: "ツナ缶", category: "肉・魚・たんぱく" },
  { name: "豆腐", category: "肉・魚・たんぱく" },
  { name: "納豆", category: "肉・魚・たんぱく" },
  { name: "厚揚げ", category: "肉・魚・たんぱく" },
  { name: "油揚げ", category: "肉・魚・たんぱく" },
  { name: "シーフードミックス", category: "肉・魚・たんぱく" },
  { name: "米", category: "穀物" },
  { name: "玄米", category: "穀物" },
  { name: "パスタ", category: "穀物" },
  { name: "うどん", category: "穀物" },
  { name: "そば", category: "穀物" },
  { name: "食パン", category: "穀物" },
  { name: "オートミール", category: "穀物" },
  { name: "春雨", category: "穀物" },
  { name: "卵", category: "乳・卵" },
  { name: "牛乳", category: "乳・卵" },
  { name: "ヨーグルト", category: "乳・卵" },
  { name: "チーズ", category: "乳・卵" },
  { name: "醤油", category: "調味料" },
  { name: "味噌", category: "調味料" },
  { name: "みりん", category: "調味料" },
  { name: "砂糖", category: "調味料" },
  { name: "ごま油", category: "調味料" },
  { name: "オリーブオイル", category: "調味料" },
  { name: "にんにく", category: "調味料" },
  { name: "しょうが", category: "調味料" },
  { name: "バター", category: "調味料" },
  { name: "ケチャップ", category: "調味料" },
  { name: "マヨネーズ", category: "調味料" },
  { name: "コンソメ", category: "調味料" },
  { name: "冷凍ごはん", category: "その他" },
  { name: "冷凍餃子", category: "その他" },
  { name: "キムチ", category: "その他" },
  { name: "わかめ", category: "その他" },
  { name: "バナナ", category: "その他" },
  { name: "りんご", category: "その他" },
];

export const STARTER_NAMES = ["卵", "玉ねぎ", "豚こま", "米", "キャベツ", "鶏もも肉"];

export const AVOID_PRESETS = ["乳製品", "小麦", "そば", "えび", "ピーナッツ", "卵"];

export function categoryOf(name: string): string {
  const hit = CATALOG.find((item) => item.name === name);
  return hit?.category ?? "その他";
}
