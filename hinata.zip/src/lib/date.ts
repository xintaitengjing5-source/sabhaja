const JST = "Asia/Tokyo";

export function todayKey(date = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: JST,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

export function weekdayIndex(dateKey: string): number {
  const [y, m, d] = dateKey.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d, 3, 0, 0)).getUTCDay();
}

export function addDays(dateKey: string, days: number): string {
  const [y, m, d] = dateKey.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + days, 3, 0, 0));
  const yy = dt.getUTCFullYear();
  const mm = String(dt.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(dt.getUTCDate()).padStart(2, "0");
  return `${yy}-${mm}-${dd}`;
}

export function mondayOf(dateKey: string): string {
  const dow = weekdayIndex(dateKey);
  const offset = dow === 0 ? -6 : 1 - dow;
  return addDays(dateKey, offset);
}

export function weekKeys(dateKey: string): string[] {
  const start = mondayOf(dateKey);
  return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}

const WEEKDAY_JA = ["日", "月", "火", "水", "木", "金", "土"] as const;

export function weekdayJa(dateKey: string): string {
  return WEEKDAY_JA[weekdayIndex(dateKey)] ?? "";
}

export function formatLong(dateKey: string): string {
  const [, m, d] = dateKey.split("-");
  return `${Number(m)}月${Number(d)}日`;
}

export function formatMonthDay(dateKey: string): string {
  const [, m, d] = dateKey.split("-");
  return `${Number(m)}/${Number(d)}`;
}

export const WEEK_ORDER = [1, 2, 3, 4, 5, 6, 0] as const;
export const WEEKDAY_SHORT = ["日", "月", "火", "水", "木", "金", "土"] as const;
