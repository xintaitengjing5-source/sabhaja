import { cn } from "@/lib/cn";
import { formatLong, weekdayJa } from "@/lib/date";
import { GOAL_LABEL } from "@/lib/types";
import { useKitchen } from "@/lib/store";

export function HeroBlock({ today, cheat }: { today: string; cheat: boolean }) {
  const profile = useKitchen((s) => s.profile);

  return (
    <div className="enter-1">
      <p className="text-xs tracking-widest text-muted">
        {formatLong(today)}
        <span className="mx-2 text-border">/</span>
        {weekdayJa(today)}曜日
        <span className="mx-2 text-border">/</span>
        {GOAL_LABEL[profile.goal]}
      </p>
      <h1
        className={cn(
          "mt-3 font-display text-4xl leading-tight tracking-tight sm:text-5xl",
          cheat ? "text-cheat" : "text-fg",
        )}
      >
        {cheat ? "今日はチートデイ" : "今日のごはんを選ぶ"}
      </h1>
      <p className="mt-3 max-w-md text-sm leading-relaxed text-muted">
        {cheat
          ? "冷蔵庫の食材で、ごちそう多めの候補を出します。食べたいものを選んでください。"
          : "いつもの家庭料理から、ちょっとしたごちそうまで。候補の中から選ぶだけ。"}
      </p>
    </div>
  );
}
