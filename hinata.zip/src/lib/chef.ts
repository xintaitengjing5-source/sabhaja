import type { Goal, MealPart, MealType, Pace, SuggestedMeal, Vibe } from "./types";

export type ChefInput = {
  ingredients: string[];
  avoids: string[];
  goal: Goal;
  calories: number;
  protein: number;
  servings: number;
  cheat: boolean;
  mealCount: 1 | 3;
  pace: Pace;
};

type Group = "protein" | "veg" | "carb" | "dairy";

const GROUP: Record<string, Group> = {
  鶏むね肉: "protein",
  鶏もも肉: "protein",
  豚こま: "protein",
  豚バラ: "protein",
  牛薄切り: "protein",
  ひき肉: "protein",
  鮭: "protein",
  さば: "protein",
  ツナ缶: "protein",
  豆腐: "protein",
  納豆: "protein",
  厚揚げ: "protein",
  油揚げ: "protein",
  シーフードミックス: "protein",
  卵: "protein",
  玉ねぎ: "veg",
  にんじん: "veg",
  じゃがいも: "veg",
  キャベツ: "veg",
  トマト: "veg",
  ほうれん草: "veg",
  ブロッコリー: "veg",
  きゅうり: "veg",
  なす: "veg",
  ピーマン: "veg",
  きのこ: "veg",
  白菜: "veg",
  ねぎ: "veg",
  小松菜: "veg",
  もやし: "veg",
  さつまいも: "veg",
  アボカド: "veg",
  レタス: "veg",
  米: "carb",
  玄米: "carb",
  パスタ: "carb",
  うどん: "carb",
  そば: "carb",
  食パン: "carb",
  オートミール: "carb",
  春雨: "carb",
  冷凍ごはん: "carb",
  牛乳: "dairy",
  ヨーグルト: "dairy",
  チーズ: "dairy",
  バター: "dairy",
};

const SEASONING = new Set([
  "醤油",
  "味噌",
  "みりん",
  "砂糖",
  "ごま油",
  "オリーブオイル",
  "にんにく",
  "しょうが",
  "ケチャップ",
  "マヨネーズ",
  "コンソメ",
  "キムチ",
  "冷凍餃子",
  "わかめ",
]);

function blocked(name: string, avoids: string[]): boolean {
  const table: Record<string, string[]> = {
    卵: ["卵"],
    牛乳: ["乳製品"],
    ヨーグルト: ["乳製品"],
    チーズ: ["乳製品"],
    バター: ["乳製品"],
    食パン: ["小麦"],
    パスタ: ["小麦"],
    うどん: ["小麦"],
    そば: ["そば", "小麦"],
    冷凍餃子: ["小麦"],
  };
  return (table[name] ?? []).some((item) => avoids.includes(item));
}

function minutesFor(pace: Pace, base: number): number {
  if (pace === "quick") return Math.max(10, base - 8);
  if (pace === "slow") return base + 12;
  return base;
}

function scaleCal(goal: Goal, vibe: Vibe, daily: number): number {
  let cal = daily * 0.36;
  if (goal === "cut") cal *= 0.94;
  if (goal === "bulk") cal *= 1.1;
  if (vibe === "light") cal *= 0.8;
  if (vibe === "feast") cal *= 1.28;
  return Math.round(cal);
}

function macros(cal: number, proteinTarget: number, vibe: Vibe) {
  const pShare = vibe === "light" ? 0.38 : vibe === "feast" ? 0.28 : 0.32;
  const protein = Math.round(proteinTarget * pShare);
  const fatRatio = vibe === "feast" ? 0.38 : vibe === "home" ? 0.3 : 0.22;
  const fat = Math.round((fatRatio * cal) / 9);
  const carbs = Math.max(12, Math.round((cal - protein * 4 - fat * 9) / 4));
  return { protein, fat, carbs };
}

type Ctx = {
  proteins: string[];
  vegs: string[];
  carbs: string[];
  dairy: string[];
  all: string[];
  cheat: boolean;
  goal: Goal;
  pace: Pace;
  calories: number;
  protein: number;
  servings: number;
};

function has(list: string[], name: string) {
  return list.includes(name);
}

function first(list: string[], names: string[]) {
  return names.find((n) => list.includes(n));
}

function pick(list: string[], n = 2) {
  return list.slice(0, n);
}

function g(servings: number, base: number) {
  return `${base * servings}g`;
}

function spoon(servings: number, n: number, unit: "大さじ" | "小さじ") {
  const v = n * servings;
  return Number.isInteger(v) ? `${unit}${v}` : `${unit}${v}`;
}

type RecipeFn = (ctx: Ctx) => SuggestedMeal | null;

function plate(
  ctx: Ctx,
  spec: {
    title: string;
    vibe: Vibe;
    mealType: MealType;
    minutes: number;
    why: string;
    used: (string | undefined)[];
    extras?: string[];
    parts: MealPart[];
    steps: string[];
    tip: string;
  },
): SuggestedMeal {
  const cal = scaleCal(ctx.goal, spec.vibe, ctx.calories);
  return {
    title: spec.title,
    mealType: spec.mealType,
    vibe: spec.vibe,
    minutes: minutesFor(ctx.pace, spec.minutes),
    calories: cal,
    ...macros(cal, ctx.protein, spec.vibe),
    why: spec.why,
    used: spec.used.filter((v): v is string => Boolean(v)),
    extras: spec.extras ?? [],
    parts: spec.parts,
    steps: spec.steps,
    tip: spec.tip,
  };
}

const gingerPork: RecipeFn = (ctx) => {
  const pork = first(ctx.proteins, ["豚こま", "豚バラ", "牛薄切り"]);
  if (!pork) return null;
  const onion = first(ctx.vegs, ["玉ねぎ", "キャベツ", "もやし"]) ?? ctx.vegs[0];
  const rice = first(ctx.carbs, ["米", "冷凍ごはん", "玄米"]);
  const s = ctx.servings;
  return plate(ctx, {
    title: "豚の生姜焼き",
    vibe: "home",
    mealType: "dinner",
    minutes: 20,
    why: "定番の味。ごはんが進む。玉ねぎの甘みでタレがまろやかになります。",
    used: [pork, onion, rice, first(ctx.all, ["しょうが"])],
    extras: has(ctx.all, "しょうが") ? [] : ["しょうが"],
    parts: [
      { name: pork, amount: g(s, 150) },
      { name: onion ?? "玉ねぎ", amount: s === 1 ? "1/2個" : `${s / 2}個` },
      { name: "しょうが（すりおろし）", amount: spoon(s, 1, "大さじ") },
      { name: "醤油", amount: spoon(s, 2, "大さじ") },
      { name: "みりん", amount: spoon(s, 2, "大さじ") },
      { name: "砂糖", amount: spoon(s, 1, "小さじ") },
      { name: "サラダ油", amount: spoon(s, 1, "大さじ") },
      ...(rice ? [{ name: rice, amount: s === 1 ? "茶碗1杯" : `茶碗${s}杯` }] : []),
    ],
    steps: [
      `${pork}は食べやすい大きさに広げ、キッチンペーパーで水気を拭く。しょうがはすりおろす。`,
      `ボウルに醤油${spoon(s, 2, "大さじ")}、みりん${spoon(s, 2, "大さじ")}、砂糖${spoon(s, 1, "小さじ")}、しょうがを混ぜてタレを作る。`,
      `${onion ?? "玉ねぎ"}は繊維に沿って5mm幅の薄切り。`,
      `フライパンを中火で熱し、油${spoon(s, 1, "大さじ")}をひく。${pork}を重ならないように並べ、片面1分半焼いて返す。焼き色がついたら一旦取り出す。`,
      `同じフライパンで${onion ?? "玉ねぎ"}を2分炒める。しんなりしたら肉を戻し、タレを回し入れる。`,
      `中火のまま1分ほど絡める。照りが出てタレがとろみづいたら火を止める。`,
      rice
        ? `${rice}を茶碗によそい、生姜焼きをのせる。タレも全部かける。`
        : "皿に盛り、タレをかけて出す。",
    ],
    tip: "肉を重ねて焼くと水が出るので、一度に焼ききれないときは二回に分ける。",
  });
};

const oyakodon: RecipeFn = (ctx) => {
  if (!has(ctx.proteins, "卵")) return null;
  const chicken = first(ctx.proteins, ["鶏もも肉", "鶏むね肉", "豚こま"]);
  if (!chicken) return null;
  const onion = first(ctx.vegs, ["玉ねぎ", "ねぎ"]) ?? ctx.vegs[0];
  const rice = first(ctx.carbs, ["米", "冷凍ごはん", "玄米"]);
  const s = ctx.servings;
  return plate(ctx, {
    title: "親子丼",
    vibe: "home",
    mealType: "lunch",
    minutes: 20,
    why: "卵と鶏肉の定番どんぶり。つゆをしっかり含ませると、それだけでごはんがおいしい。",
    used: [chicken, "卵", onion, rice],
    extras: rice ? [] : ["ごはん"],
    parts: [
      { name: chicken, amount: g(s, 120) },
      { name: "卵", amount: `${2 * s}個` },
      { name: onion ?? "玉ねぎ", amount: s === 1 ? "1/2個" : `${Math.ceil(s / 2)}個` },
      { name: "だし汁（水＋和風だし）", amount: `${80 * s}ml` },
      { name: "醤油", amount: spoon(s, 1.5, "大さじ") },
      { name: "みりん", amount: spoon(s, 1, "大さじ") },
      { name: "砂糖", amount: spoon(s, 1, "小さじ") },
      ...(rice ? [{ name: rice, amount: s === 1 ? "茶碗1杯" : `茶碗${s}杯` }] : []),
    ],
    steps: [
      `${chicken}は一口大。${onion ?? "玉ねぎ"}は5mm幅の薄切り。卵はボウルで軽く溶く（白身が切れればよい）。`,
      `小さめのフライパンにだし${80 * s}ml、醤油、みりん、砂糖を入れて中火。煮立ったら${onion ?? "玉ねぎ"}を入れる。`,
      `1分煮てしんなりしたら${chicken}を加え、ふたをして3分。火が通るまで待つ。`,
      `溶き卵の2/3を回し入れ、ふたをして20秒。半熟になったら残りの卵を回し、10秒で火を止める。`,
      rice
        ? `温かい${rice}をどんぶりによそい、卵とじをのせる。つゆも全部かける。`
        : "器に盛り、あればご飯にのせる。",
      "刻みねぎがあれば散らす。卵は余熱で固まるので、固めすぎない。",
    ],
    tip: "卵は二度に分けて入れると、とろみと黄身の粒が両方残る。",
  });
};

const friedRice: RecipeFn = (ctx) => {
  const rice = first(ctx.carbs, ["米", "冷凍ごはん", "玄米"]);
  if (!rice || !has(ctx.proteins, "卵")) return null;
  const meat = first(ctx.proteins, ["豚こま", "豚バラ", "ひき肉", "鶏もも肉", "鶏むね肉", "ツナ缶"]);
  const veg = pick(
    ctx.vegs.filter((v) => ["玉ねぎ", "ねぎ", "にんじん", "ピーマン", "キャベツ", "もやし"].includes(v)),
    2,
  );
  const vegs = veg.length ? veg : pick(ctx.vegs, 2);
  const s = ctx.servings;
  return plate(ctx, {
    title: meat ? `${meat}のチャーハン` : "卵チャーハン",
    vibe: "home",
    mealType: "lunch",
    minutes: 15,
    why: "冷めたご飯が一番。強火でパラパラにすると、中華屋の味に近づきます。",
    used: [rice, "卵", meat, ...vegs],
    extras: [],
    parts: [
      { name: rice, amount: s === 1 ? "茶碗2杯ぶん（冷まし）" : `茶碗${2 * s}杯ぶん` },
      { name: "卵", amount: `${s + 1}個` },
      ...(meat ? [{ name: meat, amount: g(s, 80) }] : []),
      ...vegs.map((v) => ({ name: v, amount: g(s, 40) })),
      { name: "醤油", amount: spoon(s, 1, "大さじ") },
      { name: "塩", amount: "少々" },
      { name: "ごま油", amount: spoon(s, 1, "小さじ") },
    ],
    steps: [
      `${rice}はほぐしておく。冷凍ならレンジで温めて、粒を崩す。卵は溶いて塩ひとつまみ。`,
      `${vegs.join("、") || "野菜"}は5mm角。肉があれば同じく小さく切る。`,
      `フライパンを強火で熱し、油大さじ1。溶き卵を入れて10秒炒め、半熟のうちに一旦取り出す。`,
      meat
        ? `${meat}を同じフライパンで炒め、色が変わったら野菜を加えて1分。`
        : `野菜を1分炒める。`,
      `${rice}を加えて米粒をほぐすように2分。卵を戻し、醤油を周りから回し入れて一気に混ぜる。`,
      `火を止めてごま油を回し、塩で味を見る。皿に高く盛る。`,
    ],
    tip: "ご飯が熱いとべちゃつく。必ず冷ますか、冷凍ごはんを使う。",
  });
};

const nikujaga: RecipeFn = (ctx) => {
  const meat = first(ctx.proteins, ["牛薄切り", "豚こま", "豚バラ", "鶏もも肉"]);
  if (!meat || !has(ctx.vegs, "じゃがいも")) return null;
  const onion = first(ctx.vegs, ["玉ねぎ"]);
  const carrot = first(ctx.vegs, ["にんじん"]);
  const s = ctx.servings;
  return plate(ctx, {
    title: "肉じゃが",
    vibe: "home",
    mealType: "dinner",
    minutes: 35,
    why: "煮汁がじゃがいもに染みるまで待つ。翌日さらにおいしい、普通の夕食。",
    used: [meat, "じゃがいも", onion, carrot],
    extras: [],
    parts: [
      { name: meat, amount: g(s, 120) },
      { name: "じゃがいも", amount: `${2 * s}個` },
      ...(onion ? [{ name: "玉ねぎ", amount: `${s}個` }] : []),
      ...(carrot ? [{ name: "にんじん", amount: s === 1 ? "1/2本" : `${s / 2}本` }] : []),
      { name: "水", amount: `${300 * s}ml` },
      { name: "醤油", amount: spoon(s, 2, "大さじ") },
      { name: "みりん", amount: spoon(s, 2, "大さじ") },
      { name: "砂糖", amount: spoon(s, 1, "大さじ") },
    ],
    steps: [
      `じゃがいもは皮をむいて乱切り、水に5分さらして澱粉を出す。玉ねぎはくし切り、にんじんは乱切り。${meat}は食べやすい長さ。`,
      `鍋を中火で熱し、油小さじ1。${meat}を炒めて色が変わったら野菜を加えて2分。`,
      `水を入れ、煮立ったらアクを取る。醤油・みりん・砂糖を加える。`,
      `落とし蓋（アルミホイルでも可）をして中火の弱で15分。じゃがいもに竹串が通ればOK。`,
      `蓋を取り、強めの中火で3分。煮汁が半分くらいになったら火を止める。`,
      `5分蒸らしてから器に盛る。ごはんがあると定食になる。`,
    ],
    tip: "じゃがいもを煮る前に水にさらすと、煮崩れしにくい。",
  });
};

const curryRice: RecipeFn = (ctx) => {
  const meat = first(ctx.proteins, ["鶏もも肉", "豚こま", "豚バラ", "牛薄切り", "ひき肉", "鶏むね肉"]);
  const potato = first(ctx.vegs, ["じゃがいも", "さつまいも"]);
  const carrot = first(ctx.vegs, ["にんじん"]);
  const onion = first(ctx.vegs, ["玉ねぎ"]);
  if (!meat || (!potato && !carrot && !onion)) return null;
  const rice = first(ctx.carbs, ["米", "冷凍ごはん", "玄米"]);
  const s = ctx.servings;
  const vegs = [onion, carrot, potato].filter((v): v is string => Boolean(v));
  return plate(ctx, {
    title: "カレーライス",
    vibe: "home",
    mealType: "dinner",
    minutes: 40,
    why: "市販のルーでいい。野菜をしっかり炒めて甘みを出すのが、おいしいカレーのコツ。",
    used: [meat, ...vegs, rice],
    extras: ["カレールー"],
    parts: [
      { name: meat, amount: g(s, 150) },
      ...vegs.map((v) => ({
        name: v,
        amount: v === "玉ねぎ" ? `${s}個` : v === "にんじん" ? `${s}本` : `${2 * s}個`,
      })),
      { name: "水", amount: `${400 * s}ml` },
      { name: "カレールー", amount: s === 1 ? "2かけ" : `${2 * s}かけ` },
      ...(rice ? [{ name: rice, amount: s === 1 ? "茶碗1.5杯" : `茶碗${Math.round(1.5 * s)}杯` }] : []),
    ],
    steps: [
      `${meat}は一口大。野菜は大きめの乱切り。玉ねぎは薄めのくし切りにすると甘みが出る。`,
      `厚手の鍋を中火で熱し、油大さじ1。玉ねぎを4分炒めて色づかせる。`,
      `${meat}を加えて表面に焼き色がつくまで3分。にんじん・じゃがいもを加えて1分。`,
      `水を入れ、煮立ったらアクを取る。ふたをして弱火で15分。野菜が柔らかくなるまで。`,
      `火を止めてルーを割り入れ、溶けるまで混ぜる。再点火して弱火で8分、ときどき混ぜる。`,
      rice
        ? `ご飯を皿の半分によそい、カレーをかける。福神漬けがあれば添える。`
        : "器に盛る。ご飯があると完成。",
    ],
    tip: "ルーを入れたあとは絶対に煮立たせない。底が焦げやすい。",
  });
};

const gyudon: RecipeFn = (ctx) => {
  const beef = first(ctx.proteins, ["牛薄切り", "豚こま"]);
  if (!beef || !has(ctx.vegs, "玉ねぎ")) return null;
  const rice = first(ctx.carbs, ["米", "冷凍ごはん", "玄米"]);
  const s = ctx.servings;
  return plate(ctx, {
    title: beef === "牛薄切り" ? "牛丼" : "豚丼",
    vibe: "home",
    mealType: "lunch",
    minutes: 15,
    why: "甘辛い汁がごはんに染みる。紅生姜がなくても、ねぎで十分うまい。",
    used: [beef, "玉ねぎ", rice, first(ctx.proteins, ["卵"])],
    extras: rice ? [] : ["ごはん"],
    parts: [
      { name: beef, amount: g(s, 150) },
      { name: "玉ねぎ", amount: s === 1 ? "1/2個" : `${s / 2}個` },
      { name: "だし汁", amount: `${100 * s}ml` },
      { name: "醤油", amount: spoon(s, 2, "大さじ") },
      { name: "みりん", amount: spoon(s, 2, "大さじ") },
      { name: "砂糖", amount: spoon(s, 1, "大さじ") },
      ...(rice ? [{ name: rice, amount: s === 1 ? "茶碗1杯" : `茶碗${s}杯` }] : []),
    ],
    steps: [
      `玉ねぎは薄切り。${beef}は食べやすい長さに切る。`,
      `フライパンにだし、醤油、みりん、砂糖を入れて中火。煮立ったら玉ねぎを入れる。`,
      `2分煮てしんなりしたら${beef}を広げて入れ、箸でほぐす。`,
      `再沸騰したら弱火で3分。肉の色が変われば火は通っている。`,
      rice ? `どんぶりに${rice}をよそい、肉と玉ねぎをのせる。つゆをたっぷりかける。` : "器に盛る。",
      has(ctx.proteins, "卵")
        ? "生卵または温泉卵を落とすと、さらにごちそう。"
        : "紅生姜やねぎがあれば添える。",
    ],
    tip: "沸騰しすぎると肉が硬くなる。入れたら弱火に落とす。",
  });
};

const vegetableStirFry: RecipeFn = (ctx) => {
  const meat = first(ctx.proteins, ["豚こま", "豚バラ", "鶏もも肉", "鶏むね肉", "厚揚げ", "豆腐"]);
  if (!meat || ctx.vegs.length < 2) return null;
  const veg = pick(ctx.vegs, 3);
  const s = ctx.servings;
  return plate(ctx, {
    title: `${meat}と野菜炒め`,
    vibe: "home",
    mealType: "dinner",
    minutes: 18,
    why: "夜の定番。塩胡椒と醤油だけでいい。野菜の歯ごたえを残すのがうまさ。",
    used: [meat, ...veg],
    extras: [],
    parts: [
      { name: meat, amount: g(s, 120) },
      ...veg.map((v) => ({ name: v, amount: g(s, 80) })),
      { name: "醤油", amount: spoon(s, 1, "大さじ") },
      { name: "塩・胡椒", amount: "各少々" },
      { name: "ごま油", amount: spoon(s, 1, "小さじ") },
    ],
    steps: [
      `${meat}は一口大。${veg.join("、")}は食べやすい大きさに切る。火の通りにくいものから切っておく。`,
      `フライパンを中強火で熱し、油大さじ1。${meat}を広げて焼き、片面1分半。`,
      `肉の色が変わったら、火の通りにくい野菜から順に加える。${veg[0]}を先に1分。`,
      `残りの野菜を加えて強火で2分。塩胡椒を振り、最後に醤油を周りから回す。`,
      `火を止めてごま油。混ぜたらすぐに皿へ。ごはんまたは白米があれば定食。`,
    ],
    tip: "野菜から水が出たら、蓋をせず強火のまま飛ばす。",
  });
};

const maboTofu: RecipeFn = (ctx) => {
  const tofu = first(ctx.proteins, ["豆腐", "厚揚げ"]);
  if (!tofu) return null;
  const meat = first(ctx.proteins, ["ひき肉", "豚こま", "豚バラ"]);
  const onion = first(ctx.vegs, ["ねぎ", "玉ねぎ", "にんにく"]);
  const rice = first(ctx.carbs, ["米", "冷凍ごはん", "玄米"]);
  const s = ctx.servings;
  return plate(ctx, {
    title: meat ? "麻婆豆腐" : `${tofu}の甘辛炒め`,
    vibe: "feast",
    mealType: "dinner",
    minutes: 22,
    why: "豆板醤がなくても、醤油・砂糖・ごま油で十分おいしい。ご飯が何杯でもいける。",
    used: [tofu, meat, onion, rice, first(ctx.all, ["にんにく"])],
    extras: ["豆板醤"],
    parts: [
      { name: tofu, amount: s === 1 ? "1丁" : `${s}丁` },
      ...(meat ? [{ name: meat, amount: g(s, 80) }] : []),
      { name: onion ?? "ねぎ", amount: s === 1 ? "1/2本" : `${s}本` },
      { name: "醤油", amount: spoon(s, 1.5, "大さじ") },
      { name: "砂糖", amount: spoon(s, 1, "小さじ") },
      { name: "片栗粉", amount: spoon(s, 1, "小さじ") },
      { name: "ごま油", amount: spoon(s, 1, "大さじ") },
    ],
    steps: [
      `${tofu}は2cm角に切り、熱湯を回しかけて1分置く（水気と臭みを取る）。ざるに上げる。`,
      `ねぎは小口切り。にんにくがあればみじん切り。片栗粉は水大さじ1で溶いておく。`,
      `フライパンにごま油、中火。にんにく・ねぎの白い部分を30秒炒めて香りを出す。`,
      meat
        ? `${meat}を加えてほぐし、色が変わるまで2分。豆板醤があれば小さじ1をここで。`
        : "豆腐を入れて両面を軽く焼く。",
      `${tofu}を加えて崩さないように混ぜ、醤油と砂糖、水${80 * s}mlを入れる。2分煮る。`,
      `水溶き片栗粉を回し、とろみがついたら火を止める。青ねぎを散らす。`,
      rice ? `${rice}によそってかける。` : "器に盛る。ご飯があると完成。",
    ],
    tip: "豆腐は最初に湯通しすると、煮崩れしにくく、味が入りやすい。",
  });
};

const carbonara: RecipeFn = (ctx) => {
  if (!has(ctx.carbs, "パスタ") || !has(ctx.proteins, "卵")) return null;
  const cheese = first(ctx.dairy, ["チーズ"]);
  const meat = first(ctx.proteins, ["豚バラ", "豚こま", "ベーコン"]);
  const s = ctx.servings;
  return plate(ctx, {
    title: "カルボナーラ",
    vibe: "feast",
    mealType: "lunch",
    minutes: 20,
    why: "卵とチーズと胡椒。ソースは余熱で作る。火にかけすぎないのがコツ。",
    used: ["パスタ", "卵", cheese, meat, first(ctx.dairy, ["牛乳"])],
    extras: cheese ? [] : ["チーズ"],
    parts: [
      { name: "パスタ", amount: g(s, 100) },
      { name: "卵", amount: `${s + 1}個（黄身多めでも可）` },
      { name: cheese ?? "チーズ", amount: g(s, 30) },
      ...(meat ? [{ name: meat, amount: g(s, 60) }] : []),
      { name: "黒胡椒", amount: "多め" },
      { name: "塩", amount: "茹で湯に小さじ2" },
    ],
    steps: [
      `たっぷりの湯を沸かし、塩を入れてパスタを表示時間どおりに茹でる。`,
      `ボウルに卵、チーズ、黒胡椒をよく混ぜてソースのベースを作る。`,
      meat
        ? `フライパンで${meat}を中火で3分焼き、脂を出す。火を止めておく。`
        : "フライパンにバターまたは油小さじ1を温めておく。",
      `パスタを茹で汁大さじ3ごとフライパンへ。さっと絡めたら火を完全に止める。`,
      `卵液を回し入れ、茹で汁でのばしながら素早く混ぜる。とろみがついたら完成。`,
      `皿に盛り、黒胡椒をさらに振る。固まったら茹で汁を足してゆるめる。`,
    ],
    tip: "ソースを火にかけるとスクランブルエッグになる。必ず火を止めてから卵を入れる。",
  });
};

const napolitan: RecipeFn = (ctx) => {
  if (!has(ctx.carbs, "パスタ")) return null;
  const onion = first(ctx.vegs, ["玉ねぎ", "ピーマン", "キャベツ"]);
  const meat = first(ctx.proteins, ["ソーセージ", "豚こま", "ハム", "鶏もも肉"]);
  const s = ctx.servings;
  const ketchup = has(ctx.all, "ケチャップ");
  return plate(ctx, {
    title: "ナポリタン",
    vibe: "feast",
    mealType: "lunch",
    minutes: 18,
    why: "ケチャップ焼きそば、ではなくナポリタン。麺をケチャップで炒めて香ばしく。",
    used: ["パスタ", onion, meat, ketchup ? "ケチャップ" : undefined],
    extras: ketchup ? [] : ["ケチャップ"],
    parts: [
      { name: "パスタ", amount: g(s, 100) },
      ...(onion ? [{ name: onion, amount: s === 1 ? "1/4個" : `${s}切れ` }] : []),
      ...(meat ? [{ name: meat, amount: g(s, 60) }] : []),
      { name: "ケチャップ", amount: spoon(s, 3, "大さじ") },
      { name: "バター", amount: "10g" },
    ],
    steps: [
      `パスタを表示より1分短く茹でる。ざるに上げ、油をからめておく。`,
      `${onion ?? "玉ねぎ"}と具材を細切り。`,
      `フライパンにバター、中火。具を2分炒めて軽く色づける。`,
      `パスタを加え、ケチャップを回して強火で1分。麺に焼き色がつくまで。`,
      `塩胡椒。皿に盛って、あれば粉チーズ。`,
    ],
    tip: "ケチャップは生のままかけず、必ず炒めて酸味を飛ばす。",
  });
};

const butterSalmon: RecipeFn = (ctx) => {
  const fish = first(ctx.proteins, ["鮭", "さば"]);
  if (!fish) return null;
  const veg = pick(ctx.vegs, 2);
  const s = ctx.servings;
  return plate(ctx, {
    title: `${fish}のバター醤油`,
    vibe: "feast",
    mealType: "dinner",
    minutes: 18,
    why: "焼いたあとにバターと醤油。魚が苦手でも、これならごはんがすすむ。",
    used: [fish, ...veg, first(ctx.dairy, ["バター"])],
    extras: has(ctx.dairy, "バター") ? [] : ["バター"],
    parts: [
      { name: fish, amount: `${s}切れ` },
      { name: "塩", amount: "少々" },
      { name: "バター", amount: g(s, 10) },
      { name: "醤油", amount: spoon(s, 1, "大さじ") },
      ...veg.map((v) => ({ name: v, amount: g(s, 60) })),
    ],
    steps: [
      `${fish}は両面に塩をふり、10分置く。表面の水気をペーパーで拭く。`,
      `フライパンを中火で熱し、油小さじ1。皮目から3分焼く。動かさない。`,
      `返して2分。火が通ったら端に寄せ、バターを溶かす。`,
      `醤油を回し、スプーンで魚にかける（1分）。`,
      veg.length
        ? `${veg.join("と")}は別で塩ゆで、または同じフライパンの空いたところでさっと焼く。`
        : "あれば野菜を添える。",
      "皿に盛り、残ったバター醤油を全部かける。",
    ],
    tip: "皮目を最初にしっかり焼くと、皮がパリッとして臭みも飛ぶ。",
  });
};

const garlicPorkBelly: RecipeFn = (ctx) => {
  if (!has(ctx.proteins, "豚バラ") && !has(ctx.proteins, "豚こま")) return null;
  const pork = first(ctx.proteins, ["豚バラ", "豚こま"])!;
  const veg = pick(ctx.vegs, 2);
  const s = ctx.servings;
  return plate(ctx, {
    title: `にんにく${pork}炒め`,
    vibe: "feast",
    mealType: "dinner",
    minutes: 16,
    why: "脂とにんにく。ごはん泥棒。野菜を多めに入れて、こってりを受け止める。",
    used: [pork, ...veg, first(ctx.all, ["にんにく"])],
    extras: has(ctx.all, "にんにく") ? [] : ["にんにく"],
    parts: [
      { name: pork, amount: g(s, 150) },
      { name: "にんにく", amount: `${s + 1}片` },
      ...veg.map((v) => ({ name: v, amount: g(s, 70) })),
      { name: "醤油", amount: spoon(s, 1, "大さじ") },
      { name: "みりん", amount: spoon(s, 1, "大さじ") },
    ],
    steps: [
      `にんにくは薄切り。${pork}は3cm幅。${veg.join("、") || "野菜"}は食べやすく切る。`,
      `フライパンを中火で熱し、油なしで${pork}を並べる。脂が出るまで3分、裏返す。`,
      `にんにくを加えて30秒。香りが立ったら野菜を入れて強火で2分。`,
      `醤油とみりんを回し、1分絡める。`,
      `皿に盛る。ごはんとキムチがあると最高。`,
    ],
    tip: pork === "豚バラ" ? "最初は油を引かない。脂だけで炒める。" : "肉を広げて焼くと、水っぽくならない。",
  });
};

const omurice: RecipeFn = (ctx) => {
  if (!has(ctx.proteins, "卵")) return null;
  const rice = first(ctx.carbs, ["米", "冷凍ごはん", "玄米"]);
  if (!rice) return null;
  const meat = first(ctx.proteins, ["鶏もも肉", "ひき肉", "豚こま", "鶏むね肉"]);
  const onion = first(ctx.vegs, ["玉ねぎ", "ピーマン", "にんじん"]);
  const s = ctx.servings;
  return plate(ctx, {
    title: "オムライス",
    vibe: "feast",
    mealType: "lunch",
    minutes: 25,
    why: "ケチャップライスを卵で包む。ふわふわにすると、それだけでごちそう。",
    used: ["卵", rice, meat, onion, has(ctx.all, "ケチャップ") ? "ケチャップ" : undefined],
    extras: has(ctx.all, "ケチャップ") ? [] : ["ケチャップ"],
    parts: [
      { name: rice, amount: s === 1 ? "茶碗1.5杯" : `茶碗${Math.round(1.5 * s)}杯` },
      { name: "卵", amount: `${2 * s}個` },
      ...(meat ? [{ name: meat, amount: g(s, 60) }] : []),
      ...(onion ? [{ name: onion, amount: s === 1 ? "1/4個" : `${s}切れ` }] : []),
      { name: "ケチャップ", amount: spoon(s, 3, "大さじ") },
      { name: "牛乳", amount: spoon(s, 1, "大さじ") },
      { name: "バター", amount: "10g" },
    ],
    steps: [
      `具を細かく切る。フライパンに油、中火で肉と野菜を2分。ご飯を加えてほぐす。`,
      `ケチャップ大さじ2を加えて炒め、塩。ケチャップライスを一旦取り出し、お茶碗で山型に盛る。`,
      `卵は牛乳と塩少々で溶く。フライパンを中火で熱し、バターを溶かす。`,
      `卵液を流し、端から内側へ寄せて半熟のシートにする（40秒）。固まりきらないうちに。`,
      `ライスの上に卵をかぶせる。残りのケチャップを線でかける。`,
    ],
    tip: "卵は半熟で火を止める。余熱で固まる。",
  });
};

const karaage: RecipeFn = (ctx) => {
  const chicken = first(ctx.proteins, ["鶏もも肉", "鶏むね肉"]);
  if (!chicken) return null;
  const s = ctx.servings;
  return plate(ctx, {
    title: "鶏のからあげ",
    vibe: "feast",
    mealType: "dinner",
    minutes: 30,
    why: "下味をしっかり、衣は薄く。レモンを絞れば、いくらでもいける。",
    used: [chicken, first(ctx.all, ["しょうが", "にんにく"])],
    extras: ["片栗粉"],
    parts: [
      { name: chicken, amount: g(s, 200) },
      { name: "醤油", amount: spoon(s, 1.5, "大さじ") },
      { name: "酒またはみりん", amount: spoon(s, 1, "大さじ") },
      { name: "しょうが", amount: "すりおろし小さじ1" },
      { name: "片栗粉", amount: "大さじ4" },
      { name: "揚げ油", amount: "2cmくらい" },
    ],
    steps: [
      `${chicken}は一口大（25gくらい）。筋は切る。`,
      `ボウルで醤油、酒、しょうが、胡椒を混ぜ、肉を10分漬ける。`,
      `片栗粉をまぶす。厚くつけすぎない。余った粉は叩いて落とす。`,
      `油を170℃（箸先から細かい泡）。4分揚げる。一度取り出す。`,
      `油を190℃にして1分再揚げ。表面がカリッとしたら上げ、網で1分置く。`,
      `レモンまたはマヨネーズ。キャベツの千切りがあれば添える。`,
    ],
    tip: "むね肉のときは漬け汁に砂糖小さじ1を足すとパサつかない。",
  });
};

const misoSoupSet: RecipeFn = (ctx) => {
  const tofu = first(ctx.proteins, ["豆腐", "油揚げ", "わかめ"]);
  const veg = pick(
    ctx.vegs.filter((v) => ["ねぎ", "玉ねぎ", "ほうれん草", "白菜", "きのこ", "わかめ"].includes(v) || true),
    2,
  );
  const rice = first(ctx.carbs, ["米", "冷凍ごはん", "玄米"]);
  if (ctx.vegs.length === 0 && !tofu) return null;
  const s = ctx.servings;
  return plate(ctx, {
    title: rice ? "みそ汁とごはん" : "具だくさんみそ汁",
    vibe: "light",
    mealType: "breakfast",
    minutes: 12,
    why: "一番ふつうの朝。具を入れれば、それだけで一汁一飯。",
    used: [tofu, ...veg, rice, has(ctx.all, "味噌") ? "味噌" : undefined],
    extras: has(ctx.all, "味噌") ? [] : ["味噌"],
    parts: [
      { name: "水", amount: `${300 * s}ml` },
      { name: "味噌", amount: spoon(s, 1, "大さじ") },
      ...(tofu ? [{ name: tofu, amount: s === 1 ? "1/4丁" : `${s / 4}丁` }] : []),
      ...veg.map((v) => ({ name: v, amount: g(s, 40) })),
      ...(rice ? [{ name: rice, amount: s === 1 ? "茶碗1杯" : `茶碗${s}杯` }] : []),
    ],
    steps: [
      `鍋に水を入れて中火。わかめ以外の野菜を入れる。`,
      `煮立ったら${tofu ?? "具"}を加え、1分。`,
      `火を止めて味噌を溶き入れる。再沸騰させない。`,
      `ねぎがあれば最後に散らす。`,
      rice ? `${rice}と一緒に。卵があれば生卵をかける。` : "器に盛る。",
    ],
    tip: "味噌は火を止めてから。煮ると香りが飛ぶ。",
  });
};

const saltChicken: RecipeFn = (ctx) => {
  const chicken = first(ctx.proteins, ["鶏むね肉", "鶏もも肉"]);
  if (!chicken) return null;
  const veg = pick(ctx.vegs, 2);
  const s = ctx.servings;
  return plate(ctx, {
    title: `${chicken}の塩こうじ風ソテー`,
    vibe: "light",
    mealType: "dinner",
    minutes: 18,
    why: "塩と胡椒とレモン。シンプルだけど、焼けばおいしい。",
    used: [chicken, ...veg],
    extras: [],
    parts: [
      { name: chicken, amount: g(s, 150) },
      { name: "塩", amount: "小さじ1/2" },
      { name: "胡椒", amount: "少々" },
      { name: "オリーブオイル", amount: spoon(s, 1, "小さじ") },
      ...veg.map((v) => ({ name: v, amount: g(s, 80) })),
    ],
    steps: [
      `${chicken}は厚みを半分に開き、塩胡椒を両面にふって5分置く。`,
      `フライパンを中火で熱し、油。鶏肉を皮目または見た目のよい面から4分。`,
      `返して3分。竹串を刺して透明な汁が出れば火が通っている。`,
      `取り出し、2分休ませる。同じフライパンで野菜を塩ごと2分。`,
      `肉を切って盛り、レモンまたは酢を数滴。`,
    ],
    tip: "焼いたあと休ませると、汁が外に出ない。",
  });
};

const salmonSalt: RecipeFn = (ctx) => {
  const fish = first(ctx.proteins, ["鮭", "さば"]);
  if (!fish) return null;
  const veg = pick(ctx.vegs, 2);
  const rice = first(ctx.carbs, ["米", "冷凍ごはん", "玄米"]);
  const s = ctx.servings;
  return plate(ctx, {
    title: `${fish}の塩焼き定食`,
    vibe: "light",
    mealType: "breakfast",
    minutes: 15,
    why: "朝から魚、がいちばん落ち着く日もある。塩だけ、皮目から。",
    used: [fish, ...veg, rice],
    extras: [],
    parts: [
      { name: fish, amount: `${s}切れ` },
      { name: "塩", amount: "少々" },
      ...veg.map((v) => ({ name: v, amount: g(s, 60) })),
      ...(rice ? [{ name: rice, amount: s === 1 ? "茶碗1杯" : `茶碗${s}杯` }] : []),
    ],
    steps: [
      `${fish}に塩をふり、5分置く。水気を拭く。`,
      `オーブントースターなら片面4分ずつ。フライパンなら皮目から中火3分、裏2分。`,
      veg.length ? `${veg.join("と")}は塩ゆで、またはレンジ600Wで2分。` : "あれば野菜を添える。",
      rice ? `ご飯、魚、野菜を並べる。醤油は数滴で足りる。` : "皿に盛る。",
    ],
    tip: "焼きすぎるとパサパサ。身が割れ始めたら火を止める。",
  });
};

const nattoRice: RecipeFn = (ctx) => {
  if (!has(ctx.proteins, "納豆")) return null;
  const rice = first(ctx.carbs, ["米", "冷凍ごはん", "玄米", "食パン"]);
  const herb = first(ctx.vegs, ["ねぎ", "玉ねぎ", "キムチ"]);
  const s = ctx.servings;
  return plate(ctx, {
    title: "納豆ごはん",
    vibe: "light",
    mealType: "breakfast",
    minutes: 8,
    why: "混ぜる。それだけ。ねぎと卵黄があれば、急にごちそうになる。",
    used: ["納豆", rice, herb, first(ctx.proteins, ["卵"])],
    extras: [],
    parts: [
      { name: "納豆", amount: `${s}パック` },
      ...(rice ? [{ name: rice, amount: s === 1 ? "茶碗1杯" : `茶碗${s}杯` }] : []),
      ...(herb ? [{ name: herb, amount: "適量" }] : []),
    ],
    steps: [
      `納豆は付属のタレを全部入れず、半分にしてよく混ぜる（20回）。`,
      rice ? `温かい${rice}にのせる。` : "あればご飯またはトーストに。",
      herb ? `${herb}を乗せる。` : "海苔があれば散らす。",
      has(ctx.proteins, "卵") ? "生卵の黄身を落とすと、まろやかになる。" : "からしを多めにすると塩を足さずに味が立つ。",
    ],
    tip: "よく混ぜるほど糸が立ち、味がまろやか。",
  });
};

const tofuSalad: RecipeFn = (ctx) => {
  const tofu = first(ctx.proteins, ["豆腐"]);
  if (!tofu) return null;
  const veg = pick(ctx.vegs, 3);
  if (veg.length === 0) return null;
  const s = ctx.servings;
  return plate(ctx, {
    title: "冷奴と野菜",
    vibe: "light",
    mealType: "lunch",
    minutes: 10,
    why: "切って乗せるだけ。暑い日も、ちゃんとごはん。",
    used: [tofu, ...veg],
    extras: [],
    parts: [
      { name: tofu, amount: s === 1 ? "1/2丁" : `${s / 2}丁` },
      ...veg.map((v) => ({ name: v, amount: g(s, 50) })),
      { name: "醤油", amount: "小さじ2" },
      { name: "ごま油", amount: "数滴" },
    ],
    steps: [
      `豆腐は冷蔵庫から出して、2cmの厚さに切る。水気をペーパーで軽く押す。`,
      `${veg.join("、")}は食べやすく切る。葉物はざく切り、きゅうりは輪切り。`,
      `皿に豆腐、野菜を乗せる。醤油とごま油、あればおろし生姜。`,
      `ねぎや海苔があれば散らす。`,
    ],
    tip: "木綿の方が崩れず、絹の方が口あたりがよい。",
  });
};

const hamburger: RecipeFn = (ctx) => {
  if (!has(ctx.proteins, "ひき肉")) return null;
  const onion = first(ctx.vegs, ["玉ねぎ"]);
  const s = ctx.servings;
  return plate(ctx, {
    title: "ハンバーグ",
    vibe: "feast",
    mealType: "dinner",
    minutes: 30,
    why: "玉ねぎをしっかり炒めて甘く。中はジューシー、表面は焼き色。",
    used: ["ひき肉", onion, first(ctx.proteins, ["卵"]), first(ctx.carbs, ["食パン"])],
    extras: ["パン粉"],
    parts: [
      { name: "ひき肉", amount: g(s, 150) },
      { name: onion ?? "玉ねぎ", amount: s === 1 ? "1/4個" : `${s / 4}個` },
      { name: "卵", amount: s === 1 ? "1/2個" : `${Math.ceil(s / 2)}個` },
      { name: "パン粉", amount: spoon(s, 2, "大さじ") },
      { name: "塩", amount: "小さじ1/3" },
      { name: "醤油・みりん（たれ）", amount: "各大さじ1" },
    ],
    steps: [
      `玉ねぎはみじん切り。油で中火5分、飴色になるまで炒めて冷ます。`,
      `ボウルにひき肉、塩。粘りが出るまで手で練る（1分）。玉ねぎ、卵、パン粉を加えて混ぜ、4等分して小判型。`,
      `真ん中をくぼませる。フライパンを中火で熱し、油。表面に焼き色がつくまで2分ずつ。`,
      `ふたをして弱火5分。竹串を刺して透明な汁が出ればOK。`,
      `肉を取り出し、同じフライパンに醤油とみりん。1分煮てたれにする。`,
      `ハンバーグにたれをかける。じゃがいもや野菜があれば添える。`,
    ],
    tip: "ひき肉は冷たいまま練る。温まると脂が溶けてパサつく。",
  });
};

const udonBowl: RecipeFn = (ctx) => {
  const noodle = first(ctx.carbs, ["うどん", "そば"]);
  if (!noodle) return null;
  const meat = first(ctx.proteins, ["鶏もも肉", "豚こま", "油揚げ", "卵"]);
  const veg = pick(ctx.vegs, 2);
  const s = ctx.servings;
  const egg = has(ctx.proteins, "卵");
  return plate(ctx, {
    title: egg ? `${noodle}の月見あんかけ` : `${noodle}のさっと煮`,
    vibe: "home",
    mealType: "lunch",
    minutes: 15,
    why: "だしを効かせれば、麺だけでもごちそう。卵を落とせば店の味。",
    used: [noodle, meat, ...veg, egg ? "卵" : undefined],
    extras: [],
    parts: [
      { name: noodle, amount: `${s}玉` },
      { name: "めんつゆ（3倍濃縮）", amount: spoon(s, 2, "大さじ") },
      { name: "水", amount: `${300 * s}ml` },
      ...(meat ? [{ name: meat, amount: g(s, 60) }] : []),
      ...veg.map((v) => ({ name: v, amount: g(s, 40) })),
      ...(egg ? [{ name: "卵", amount: `${s}個` }] : []),
    ],
    steps: [
      `鍋に水とめんつゆ。中火で煮立てる。`,
      meat ? `${meat}を加えて2分。` : "だしが煮立つのを待つ。",
      veg.length ? `${veg.join("と")}を入れて1分。` : "ねぎがあれば入れる。",
      `${noodle}は別鍋で表示どおりに茹で、熱湯をかけてぬめりを取る。どんぶりに入れる。`,
      `熱い汁をかけて具をのせる。`,
      egg ? "溶き卵を回し入れるか、生卵を落とす。ふたをして20秒。" : "七味があれば振る。",
    ],
    tip: "麺の茹で汁は使わない。ぬめりがだしを濁す。",
  });
};

const kimchiFried: RecipeFn = (ctx) => {
  if (!has(ctx.all, "キムチ")) return null;
  const rice = first(ctx.carbs, ["米", "冷凍ごはん", "玄米"]);
  const meat = first(ctx.proteins, ["豚こま", "豚バラ", "ひき肉", "鶏もも肉"]);
  if (!rice) return null;
  const s = ctx.servings;
  return plate(ctx, {
    title: "キムチチャーハン",
    vibe: "feast",
    mealType: "lunch",
    minutes: 12,
    why: "キムチの汁まで炒める。辛さと脂で、止まりません。",
    used: ["キムチ", rice, meat, first(ctx.proteins, ["卵"])],
    extras: [],
    parts: [
      { name: rice, amount: s === 1 ? "茶碗2杯ぶん" : `茶碗${2 * s}杯ぶん` },
      { name: "キムチ", amount: g(s, 80) },
      ...(meat ? [{ name: meat, amount: g(s, 60) }] : []),
      { name: "ごま油", amount: spoon(s, 1, "大さじ") },
      { name: "醤油", amount: spoon(s, 1, "小さじ") },
    ],
    steps: [
      `キムチは粗みじん。ご飯はほぐす。`,
      `フライパンをごま油で中火。肉があれば先に炒めて色を変える。`,
      `キムチを加えて2分、汁気をとばす。`,
      `ご飯を加えて強火で2分。醤油を周りから。`,
      has(ctx.proteins, "卵")
        ? "溶き卵を端で炒めて混ぜる。皿に高く盛る。"
        : "皿に盛る。青ねぎがあれば散らす。",
    ],
    tip: "キムチは最初に炒めて水分を飛ばすと、ご飯がべちゃつかない。",
  });
};

const gyozaTeishoku: RecipeFn = (ctx) => {
  if (!has(ctx.all, "冷凍餃子")) return null;
  const cabbage = first(ctx.vegs, ["キャベツ", "レタス", "白菜"]);
  const rice = first(ctx.carbs, ["米", "冷凍ごはん"]);
  const s = ctx.servings;
  return plate(ctx, {
    title: "餃子定食",
    vibe: "feast",
    mealType: "dinner",
    minutes: 15,
    why: "冷凍餃子を上手に焼くだけで、夜ごはんが完成する。",
    used: ["冷凍餃子", cabbage, rice],
    extras: [],
    parts: [
      { name: "冷凍餃子", amount: `${6 * s}個` },
      { name: "油", amount: "大さじ1" },
      { name: "水", amount: "100ml" },
      ...(cabbage ? [{ name: cabbage, amount: "千切り 適量" }] : []),
    ],
    steps: [
      `フライパンを中火で熱し、油。冷凍のまま餃子を並べる（溶かさない）。`,
      `底に焼き色がついたら水を入れ、すぐに蓋。3〜4分蒸す。`,
      `蓋を取り、水気を飛ばす。最後に油小さじ1を回して30秒、底をカリッと。`,
      cabbage ? `${cabbage}を塩もみ、またはマヨネーズで和える。` : "あれば野菜を添える。",
      rice ? `ご飯、餃子、野菜。たれは醤油＋酢＋ラー油。` : "たれを添えて出す。",
    ],
    tip: "並べたあとは動かさない。皮が破れる。",
  });
};

const creamStew: RecipeFn = (ctx) => {
  if (!has(ctx.dairy, "牛乳")) return null;
  const meat = first(ctx.proteins, ["鶏もも肉", "鶏むね肉", "豚こま"]);
  const potato = first(ctx.vegs, ["じゃがいも", "にんじん", "玉ねぎ", "ブロッコリー"]);
  if (!meat || !potato) return null;
  const veg = pick(ctx.vegs, 3);
  const s = ctx.servings;
  return plate(ctx, {
    title: "クリームシチュー",
    vibe: "feast",
    mealType: "dinner",
    minutes: 35,
    why: "小麦粉と牛乳でとろみ。市販のシチュールーでも、もちろんいい。",
    used: ["牛乳", meat, ...veg],
    extras: ["小麦粉"],
    parts: [
      { name: meat, amount: g(s, 120) },
      ...veg.map((v) => ({ name: v, amount: v === "玉ねぎ" ? `${s}個` : g(s, 80) })),
      { name: "牛乳", amount: `${200 * s}ml` },
      { name: "小麦粉", amount: spoon(s, 2, "大さじ") },
      { name: "バター", amount: g(s, 10) },
      { name: "コンソメ", amount: "1個" },
    ],
    steps: [
      `肉と野菜は一口大。鍋にバターを中火で溶かし、肉を3分焼く。`,
      `野菜を加えて3分。小麦粉を振り、粉っぽさがなくなるまで混ぜる。`,
      `牛乳を少しずつ。コンソメと水100ml。煮立ったら弱火12分。`,
      `塩胡椒。とろみが足りなければ、水溶き小麦粉を足す。`,
      `器に盛る。パンまたはご飯。`,
    ],
    tip: "牛乳は冷たいまま一気に入れると分離しやすい。少しずつ。",
  });
};

const eggToast: RecipeFn = (ctx) => {
  if (!has(ctx.proteins, "卵") || !has(ctx.carbs, "食パン")) return null;
  const cheese = first(ctx.dairy, ["チーズ"]);
  const avo = first(ctx.vegs, ["アボカド", "トマト", "ほうれん草"]);
  const s = ctx.servings;
  return plate(ctx, {
    title: cheese ? "チーズ卵トースト" : "卵トースト",
    vibe: cheese ? "feast" : "home",
    mealType: "breakfast",
    minutes: 10,
    why: "朝の最短ごちそう。黄身が半熟なら、それで勝ち。",
    used: ["卵", "食パン", cheese, avo],
    extras: [],
    parts: [
      { name: "食パン", amount: `${s}枚` },
      { name: "卵", amount: `${s}個` },
      ...(cheese ? [{ name: cheese, amount: "適量" }] : []),
      { name: "バター", amount: "薄く" },
    ],
    steps: [
      `食パンにバターを塗り、トースターで2分。`,
      `フライパンに油少々、中火。卵を割り入れ、白身が固まり黄身がプルプルで取り出す（2分）。`,
      `トーストに乗せる。チーズがあれば卵の下に敷いて溶かす。`,
      avo ? `${avo}を添える。塩胡椒。` : "塩胡椒、あれば醤油を一滴。",
    ],
    tip: "卵は強火にしない。白身の端が焦げて黄身が生、が一番つらい。",
  });
};

const leftoverStir: RecipeFn = (ctx) => {
  if (ctx.proteins.length + ctx.vegs.length === 0) return null;
  const meat = ctx.proteins[0];
  const veg = pick(ctx.vegs, 3);
  const s = ctx.servings;
  return plate(ctx, {
    title: meat ? `${meat}のしょうゆ炒め` : "野菜の塩炒め",
    vibe: "home",
    mealType: "dinner",
    minutes: 14,
    why: "冷蔵庫の残りを、普通の味つけで一皿に。",
    used: [meat, ...veg, ctx.carbs[0]],
    extras: [],
    parts: [
      ...(meat ? [{ name: meat, amount: g(s, 120) }] : []),
      ...veg.map((v) => ({ name: v, amount: g(s, 70) })),
      { name: "醤油", amount: spoon(s, 1, "大さじ") },
      { name: "塩胡椒", amount: "少々" },
    ],
    steps: [
      `材料を食べやすい大きさに切る。火の通りにくいものから。`,
      `フライパンを中火で熱し、油大さじ1。${meat ?? "野菜"}から炒める。`,
      `色が変わったら残りを加えて2〜3分。`,
      `醤油を周りから回し、塩胡椒。ごはんがあればよそう。`,
    ],
    tip: "調味料は最後。先に入れると野菜から水が出る。",
  });
};

const RECIPES: RecipeFn[] = [
  gingerPork,
  oyakodon,
  friedRice,
  nikujaga,
  curryRice,
  gyudon,
  vegetableStirFry,
  maboTofu,
  carbonara,
  napolitan,
  butterSalmon,
  garlicPorkBelly,
  omurice,
  karaage,
  hamburger,
  udonBowl,
  kimchiFried,
  gyozaTeishoku,
  creamStew,
  eggToast,
  misoSoupSet,
  saltChicken,
  salmonSalt,
  nattoRice,
  tofuSalad,
  leftoverStir,
];

function split(names: string[], avoids: string[]) {
  const usable = names.filter((name) => !blocked(name, avoids));
  const proteins = usable.filter((n) => GROUP[n] === "protein");
  const vegs = usable.filter((n) => GROUP[n] === "veg");
  const carbs = usable.filter((n) => GROUP[n] === "carb");
  const dairy = usable.filter((n) => GROUP[n] === "dairy");
  const other = usable.filter((n) => !GROUP[n] && !SEASONING.has(n));
  return {
    proteins,
    vegs: [...vegs, ...other],
    carbs,
    dairy,
    all: usable,
  };
}

export function composeMeals(input: ChefInput): { advice: string; meals: SuggestedMeal[] } {
  const parts = split(input.ingredients, input.avoids);
  const ctx: Ctx = {
    ...parts,
    cheat: input.cheat,
    goal: input.goal,
    pace: input.pace,
    calories: input.calories,
    protein: input.protein,
    servings: input.servings,
  };

  const seen = new Set<string>();
  const candidates: SuggestedMeal[] = [];
  for (const make of RECIPES) {
    const meal = make(ctx);
    if (meal && !seen.has(meal.title)) {
      seen.add(meal.title);
      candidates.push(meal);
    }
  }

  const want = input.mealCount === 1 ? 6 : 9;
  const order: Vibe[] = input.cheat ? ["feast", "home", "light"] : ["home", "feast", "light"];
  const buckets: Record<Vibe, SuggestedMeal[]> = {
    light: candidates.filter((m) => m.vibe === "light"),
    home: candidates.filter((m) => m.vibe === "home"),
    feast: candidates.filter((m) => m.vibe === "feast"),
  };

  const meals: SuggestedMeal[] = [];
  while (meals.length < want) {
    let added = false;
    for (const vibe of order) {
      const next = buckets[vibe].shift();
      if (next) {
        meals.push(next);
        added = true;
        if (meals.length >= want) break;
      }
    }
    if (!added) break;
  }

  if (meals.length === 0) {
    const fallback = leftoverStir(ctx);
    if (fallback) meals.push(fallback);
  }

  return {
    advice: input.cheat
      ? "今日はごちそう寄りを多めに出しています。食べたいものを選んでください。"
      : "いつものごはん、ちょっとしたごちそう、あっさりめ。食べたいものを選んでください。",
    meals,
  };
}
