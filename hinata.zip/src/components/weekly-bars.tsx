import { cn } from "@/lib/cn";
import { weekKeys, weekdayJa } from "@/lib/date";
import { useKitchen } from "@/lib/store";

export function WeeklyBars({ today }: { today: string }) {
  const keys = weekKeys(today);
  const log = useKitchen((s) => s.log);
  const calories = useKitchen((s) => s.profile.calories);
  const isCheat = useKitchen((s) => s.isCheat);
  const totals = keys.map((key) =>
    log.filter((item) => item.date === key).reduce((s, i) => s + i.calories, 0),
  );
  const peak = Math.max(calories, ...totals, 1);

  return (
    <div className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
      <p className="mb-4 text-xs tracking-widest text-muted">7日のカロリー</p>
      <div className="flex h-28 items-end gap-2">
        {keys.map((key, i) => {
          const h = Math.max(4, Math.round((totals[i] / peak) * 100));
          const cheat = isCheat(key);
          const isToday = key === today;
          return (
            <div key={key} className="flex flex-1 flex-col items-center gap-2">
              <div className="flex h-20 w-full items-end rounded-sm bg-elevated/60">
                <div
                  className={cn(
                    "w-full rounded-sm transition-[height] duration-200 ease-out",
                    cheat ? "bg-cheat/80" : "bg-primary/80",
                    isToday && "opacity-100",
                    !isToday && totals[i] === 0 && "opacity-30",
                  )}
                  style={{ height: `${h}%` }}
                />
              </div>
              <span className="text-xs text-subtle">{weekdayJa(key)}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
