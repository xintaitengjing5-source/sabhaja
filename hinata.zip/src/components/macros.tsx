import { X } from "lucide-react";
import { useKitchen } from "@/lib/store";
import { MEAL_FULL } from "@/lib/types";
import { Progress } from "./ui/progress";

export function Macros({ today, cheat }: { today: string; cheat: boolean }) {
  const profile = useKitchen((s) => s.profile);
  const log = useKitchen((s) => s.log);
  const removeLog = useKitchen((s) => s.removeLog);
  const logs = log.filter((item) => item.date === today);
  const cal = logs.reduce((sum, item) => sum + item.calories, 0);
  const pro = logs.reduce((sum, item) => sum + item.protein, 0);
  const calPct = Math.round((cal / profile.calories) * 100);
  const proPct = Math.round((pro / profile.protein) * 100);

  return (
    <div className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
      <div className="mb-4 flex items-baseline justify-between">
        <p className="text-xs tracking-widest text-muted">きょうの記録</p>
        <p className="text-xs text-subtle">
          {logs.length === 0 ? "まだ未記録" : `${logs.length}品`}
        </p>
      </div>
      <div className="space-y-4">
        <MacroRow
          label="カロリー"
          value={`${cal}`}
          unit={`/ ${profile.calories} kcal`}
          pct={calPct}
          cheat={cheat}
        />
        <MacroRow
          label="たんぱく質"
          value={`${pro}`}
          unit={`/ ${profile.protein} g`}
          pct={proPct}
          cheat={cheat}
        />
      </div>
      {logs.length > 0 && (
        <ul className="mt-4 space-y-1 border-t border-border pt-3">
          {logs.map((item) => (
            <li
              key={item.id}
              className="flex items-center justify-between gap-2 text-sm"
            >
              <span className="min-w-0 truncate">
                <span className="mr-2 text-xs text-subtle">
                  {MEAL_FULL[item.mealType]}
                </span>
                {item.title}
              </span>
              <span className="flex items-center gap-1 text-xs text-muted tabular-nums">
                {item.calories}kcal
                <button
                  type="button"
                  className="relative flex size-8 items-center justify-center rounded-md text-subtle hover:text-fg"
                  onClick={() => removeLog(item.id)}
                  aria-label={`${item.title}の記録を消す`}
                >
                  <X className="size-3.5" />
                </button>
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function MacroRow({
  label,
  value,
  unit,
  pct,
  cheat,
}: {
  label: string;
  value: string;
  unit: string;
  pct: number;
  cheat: boolean;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between">
        <span className="text-sm text-muted">{label}</span>
        <span className="tabular-nums">
          <span className="font-display text-lg">{value}</span>
          <span className="ml-1 text-xs text-subtle">{unit}</span>
        </span>
      </div>
      <Progress value={pct} tone={cheat ? "cheat" : "primary"} />
    </div>
  );
}
