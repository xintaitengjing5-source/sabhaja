import { toast } from "sonner";
import { AVOID_PRESETS } from "@/lib/ingredients";
import { useKitchen } from "@/lib/store";
import { GOAL_LABEL, type Goal } from "@/lib/types";
import { cn } from "@/lib/cn";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";
import { todayKey } from "@/lib/date";

const GOALS: Goal[] = ["cut", "maintain", "bulk"];

export function GoalsDialog({
  open,
  onOpenChange,
  today,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  today: string;
}) {
  const profile = useKitchen((s) => s.profile);
  const setProfile = useKitchen((s) => s.setProfile);
  const toggleAvoid = useKitchen((s) => s.toggleAvoid);
  const isCheat = useKitchen((s) => s.isCheat(today));
  const toggleTodayCheat = useKitchen((s) => s.toggleTodayCheat);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85dvh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>からだの目標</DialogTitle>
          <DialogDescription>
            カロリーとたんぱく質の目安。チートは週2日まで。
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <div>
            <Label className="mb-2 block text-xs tracking-[0.14em] text-muted">
              目的
            </Label>
            <div className="grid grid-cols-3 gap-2">
              {GOALS.map((goal) => (
                <button
                  key={goal}
                  type="button"
                  onClick={() => setProfile({ goal })}
                  className={cn(
                    "h-11 rounded-md text-sm transition-colors duration-150",
                    profile.goal === goal
                      ? "bg-primary text-primary-fg"
                      : "bg-elevated text-muted hover:text-fg",
                  )}
                >
                  {GOAL_LABEL[goal]}
                </button>
              ))}
            </div>
          </div>

          <SliderField
            label="1日のカロリー"
            value={profile.calories}
            min={1400}
            max={3200}
            step={50}
            unit="kcal"
            onChange={(calories) => setProfile({ calories })}
          />
          <SliderField
            label="たんぱく質"
            value={profile.protein}
            min={50}
            max={180}
            step={5}
            unit="g"
            onChange={(protein) => setProfile({ protein })}
          />
          <SliderField
            label="人数"
            value={profile.servings}
            min={1}
            max={4}
            step={1}
            unit="人分"
            onChange={(servings) => setProfile({ servings })}
          />

          <div className="flex items-center justify-between gap-4 rounded-lg bg-elevated/60 px-3 py-3">
            <div>
              <p className="text-sm font-medium">今日だけチート</p>
              <p className="text-xs text-muted">曜日設定を1日だけ反転します</p>
            </div>
            <Switch
              checked={isCheat}
              onCheckedChange={() => {
                toggleTodayCheat(today || todayKey());
                toast(isCheat ? "通常モードに戻しました" : "今日はチートデイ");
              }}
              aria-label="今日だけチート"
            />
          </div>

          <div>
            <Label className="mb-2 block text-xs tracking-[0.14em] text-muted">
              避けたいもの
            </Label>
            <div className="flex flex-wrap gap-1.5">
              {AVOID_PRESETS.map((name) => {
                const on = profile.avoids.includes(name);
                return (
                  <button
                    key={name}
                    type="button"
                    onClick={() => toggleAvoid(name)}
                    className={cn(
                      "h-9 rounded-full px-3 text-sm transition-colors duration-150",
                      on
                        ? "bg-cheat-soft text-cheat"
                        : "bg-elevated text-muted hover:text-fg",
                    )}
                  >
                    {name}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function SliderField({
  label,
  value,
  min,
  max,
  step,
  unit,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit: string;
  onChange: (value: number) => void;
}) {
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between">
        <Label className="text-xs tracking-[0.14em] text-muted">{label}</Label>
        <span className="font-display text-lg tabular-nums">
          {value}
          <span className="ml-1 text-xs text-subtle">{unit}</span>
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-2 w-full cursor-pointer appearance-none rounded-full bg-elevated accent-primary"
      />
    </div>
  );
}
