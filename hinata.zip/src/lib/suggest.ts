import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { composeMeals } from "./chef";
import type { MealPart, MealType, SuggestedMeal, Vibe } from "./types";

const inputSchema = z.object({
  ingredients: z.array(z.string().max(40)).min(1).max(40),
  avoids: z.array(z.string().max(40)).max(20),
  goal: z.enum(["cut", "maintain", "bulk"]),
  calories: z.number().min(1000).max(4000),
  protein: z.number().min(30).max(220),
  servings: z.number().min(1).max(4),
  cheat: z.boolean(),
  mealCount: z.union([z.literal(1), z.literal(3)]),
  pace: z.enum(["quick", "normal", "slow"]),
  recentTitles: z.array(z.string().max(80)).max(8),
});

type SuggestInput = z.infer<typeof inputSchema>;

const mealTypes: MealType[] = ["breakfast", "lunch", "dinner", "snack"];
const vibes: Vibe[] = ["light", "home", "feast"];

function asMealType(value: unknown): MealType {
  return mealTypes.includes(value as MealType) ? (value as MealType) : "lunch";
}

function asVibe(value: unknown): Vibe {
  return vibes.includes(value as Vibe) ? (value as Vibe) : "home";
}

function num(value: unknown, fallback: number): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? Math.round(n) : fallback;
}

function str(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function strs(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.map(str).filter(Boolean).slice(0, 12);
}

function parseParts(value: unknown): MealPart[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap((item) => {
    if (!item || typeof item !== "object") return [];
    const row = item as Record<string, unknown>;
    const name = str(row.name);
    if (!name) return [];
    return [{ name, amount: str(row.amount) || "適量" }];
  }).slice(0, 14);
}

function parseMeals(raw: unknown): SuggestedMeal[] {
  if (!Array.isArray(raw)) return [];
  return raw.slice(0, 12).flatMap((item) => {
    if (!item || typeof item !== "object") return [];
    const row = item as Record<string, unknown>;
    const title = str(row.title);
    const steps = strs(row.steps).slice(0, 10);
    if (!title || steps.length === 0) return [];
    return [
      {
        title,
        mealType: asMealType(row.mealType),
        vibe: asVibe(row.vibe),
        minutes: Math.min(90, Math.max(5, num(row.minutes, 20))),
        calories: Math.min(1800, Math.max(80, num(row.calories, 450))),
        protein: Math.min(120, Math.max(0, num(row.protein, 20))),
        fat: Math.min(80, Math.max(0, num(row.fat, 15))),
        carbs: Math.min(180, Math.max(0, num(row.carbs, 40))),
        why: str(row.why) || "いまある食材で、普通においしく。",
        used: strs(row.used),
        extras: strs(row.extras),
        parts: parseParts(row.parts),
        steps,
        tip: str(row.tip),
      },
    ];
  });
}

function extractJson(text: string): unknown {
  const trimmed = text.trim();
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/);
  const body = fenced?.[1] ?? trimmed;
  const start = body.indexOf("{");
  const end = body.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("no json");
  return JSON.parse(body.slice(start, end + 1));
}

const goalJa = {
  cut: "減量気味",
  maintain: "いつもの量",
  bulk: "多めに食べたい",
} as const;

const paceJa = {
  quick: "20分以内の時短",
  normal: "30分前後",
  slow: "手間をかけてもよい",
} as const;

function localPlan(data: SuggestInput) {
  return { ok: true as const, ...composeMeals(data) };
}

async function askModel(data: SuggestInput, apiKey: string): Promise<{
  ok: true;
  advice: string;
  meals: SuggestedMeal[];
} | null> {
  const count = data.mealCount === 1 ? 6 : 9;

  const system =
    "あなたは日本の普通の家庭料理が得意な料理人。管理栄養士のような言い方はしない。冷蔵庫の食材を優先し、基本の調味料（塩、こしょう、醤油、油、みりん、砂糖）はあると仮定。ヘルシーな一皿から、めちゃくちゃおいしいごちそうまで幅を出して提案する。手順は分量・火加減・時間まで具体的に。出力はJSONのみ。日本語。";

  const user = [
    `食材: ${data.ingredients.join("、")}`,
    data.avoids.length ? `避けたいもの: ${data.avoids.join("、")}` : "",
    `目安: ${goalJa[data.goal]} / 1日 ${data.calories}kcal / たんぱく質 ${data.protein}g / ${data.servings}人分`,
    `今日は${data.cheat ? "チートデイ。ごちそう多め。ジャンクの寄せ集めにはしない。" : "ふつうの日。いつもの家庭料理を中心に。"}`,
    `候補を${count}品。vibeは light（あっさり）/ home（いつものごはん）/ feast（ごちそう）を混ぜる。home を多めに。`,
    `調理時間: ${paceJa[data.pace]}`,
    data.recentTitles.length
      ? `最近出した料理（重複避け）: ${data.recentTitles.join("、")}`
      : "",
    `JSON: {"advice":"今日の一言","meals":[{"title":"料理名","mealType":"breakfast|lunch|dinner|snack","vibe":"light|home|feast","minutes":20,"calories":600,"protein":28,"fat":22,"carbs":70,"why":"おいしさの一言","used":["使った食材"],"extras":["足りない少量の食材"],"parts":[{"name":"材料","amount":"分量"}],"steps":["分量と火加減の入った手順"],"tip":"失敗しないコツ"}]}`,
  ]
    .filter(Boolean)
    .join("\n");

  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      temperature: 0.75,
      max_tokens: 4000,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
    }),
  });

  if (!res.ok) return null;

  const body = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const text = body.choices?.[0]?.message?.content ?? "";
  try {
    const parsed = extractJson(text) as Record<string, unknown>;
    const meals = parseMeals(parsed.meals);
    if (meals.length === 0) return null;
    return {
      ok: true,
      advice:
        str(parsed.advice) ||
        (data.cheat
          ? "今日はごちそう寄り。食べたいものを選んでください。"
          : "いつものごはんからごちそうまで。食べたいものを選んでください。"),
      meals,
    };
  } catch {
    return null;
  }
}

export const suggestMeals = createServerFn({ method: "POST" })
  .validator(inputSchema)
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (apiKey) {
      try {
        const ai = await askModel(data, apiKey);
        if (ai) return ai;
      } catch {
        // fall through to the pantry chef
      }
    }
    return localPlan(data);
  });
