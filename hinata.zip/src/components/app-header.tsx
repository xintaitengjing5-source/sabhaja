import { Settings2 } from "lucide-react";
import { HinataMark } from "./mark";
import { Button } from "./ui/button";

export function AppHeader({ onOpenGoals }: { onOpenGoals: () => void }) {
  return (
    <header className="sticky top-0 z-30 border-b border-border/80 bg-bg/85 backdrop-blur-sm">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <div className="flex items-center gap-2.5 text-primary">
          <HinataMark className="size-8" />
          <div className="leading-none">
            <p className="font-display text-lg tracking-wide">HINATA</p>
            <p className="mt-1 text-xs tracking-widest text-muted">ひなた</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onOpenGoals}
          aria-label="目標を編集"
        >
          <Settings2 />
        </Button>
      </div>
    </header>
  );
}
