import { toast } from "sonner";
import { cn } from "@/lib/cn";
import { weekKeys, weekdayIndex, WEEKDAY_SHORT } from "@/lib/date";
import { useKitchen } from "@/lib/store";

export function WeekStrip({ today }: { today: string }) {
  const keys = weekKeys(today);
  const cheatWeekdays = useKitchen((s) => s.cheatWeekdays);
  const extraCheatDates = useKitchen((s) => s.extraCheatDates);
  const toggleCheatWeekday = useKitchen((s) => s.toggleCheatWeekday);
  const isCheat = useKitchen((s) => s.isCheat);

  return (
    <div>
      <div className="mb-3 flex items-end justify-between">
        <p className="text-xs tracking-widest text-muted">今週のリズム</p>
        <p className="text-xs text-subtle">曜日を押すとチートに</p>
      </div>
      <div className="grid grid-cols-7 gap-1.5">
        {keys.map((key) => {
          const dow = weekdayIndex(key);
          const cheat = isCheat(key);
          const isToday = key === today;
          const weekly = cheatWeekdays.includes(dow);
          const flipped = extraCheatDates.includes(key);
          return (
            <button
              key={key}
              type="button"
              onClick={() => {
                const ok = toggleCheatWeekday(dow);
                if (!ok) toast("チートは週2日まで。たまにが大事。");
              }}
              className={cn(
                "flex min-h-16 flex-col items-center justify-center rounded-lg px-1 py-2 text-center transition-[background-color,color,box-shadow] duration-150",
                cheat
                  ? "bg-cheat text-primary-fg"
                  : "bg-surface text-fg shadow-[var(--shadow-border)]",
                isToday && !cheat && "ring-2 ring-primary/40",
                isToday && cheat && "ring-2 ring-primary-fg/50",
              )}
            >
              <span className="text-xs tracking-widest opacity-80">
                {WEEKDAY_SHORT[dow]}
              </span>
              <span className="mt-1 font-display text-sm tabular-nums">
                {key.slice(-2).replace(/^0/, "")}
              </span>
              {flipped && weekly ? (
                <span className="mt-1 text-xs opacity-80">解除</span>
              ) : cheat ? (
                <span className="mt-1 text-xs tracking-wider">CHEAT</span>
              ) : null}
            </button>
          );
        })}
      </div>
    </div>
  );
}
